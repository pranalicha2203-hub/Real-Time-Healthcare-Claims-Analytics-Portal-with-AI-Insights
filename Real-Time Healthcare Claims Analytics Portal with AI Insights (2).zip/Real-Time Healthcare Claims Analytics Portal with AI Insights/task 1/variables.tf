variable "aws_region" {
  description = "AWS region for deployment"
  type        = string
  default     = "us-east-1"
}

variable "project_name" {
  type    = string
  default = "claims-platform"
}

variable "vpc_cidr" {
  type    = string
  default = "10.0.0.0/16"
}

variable "public_subnet_cidrs" {
  type    = list(string)
  default = ["10.0.1.0/24", "10.0.2.0/24"]
}

variable "private_subnet_cidrs" {
  type    = list(string)
  default = ["10.0.11.0/24", "10.0.12.0/24"]
}

variable "availability_zones" {
  type    = list(string)
  default = ["us-east-1a", "us-east-1b"]
}

variable "domain_name" {
  description = "Domain used for ACM cert / ALB HTTPS listener"
  type        = string
  default     = "claims.example.com"
}

variable "frontend_image" {
  type = string
}

variable "backend_image" {
  type = string
}

variable "kafka_instance_type" {
  type    = string
  default = "kafka.m5.large"
}

<?php
/**
 * Export Claims to PDF (HTML-based printable)
 * Health Care Claim Analytics Portal
 */

require_once 'db.php';

$search     = $conn->real_escape_string($_GET['search'] ?? '');
$status     = $conn->real_escape_string($_GET['status'] ?? '');
$claim_type = $conn->real_escape_string($_GET['claim_type'] ?? '');
$date_from  = $conn->real_escape_string($_GET['date_from'] ?? '');
$date_to    = $conn->real_escape_string($_GET['date_to'] ?? '');

$where = [];
if ($search)     $where[] = "(claim_id LIKE '%{$search}%' OR patient_name LIKE '%{$search}%')";
if ($status)     $where[] = "status = '{$status}'";
if ($claim_type) $where[] = "claim_type = '{$claim_type}'";
if ($date_from)  $where[] = "submitted_date >= '{$date_from}'";
if ($date_to)    $where[] = "submitted_date <= '{$date_to}'";
$whereStr = $where ? 'WHERE ' . implode(' AND ', $where) : '';

$result = $conn->query("
    SELECT claim_id, patient_name, patient_age, patient_gender,
           claim_type, claim_amount, status, submitted_date
    FROM claims {$whereStr}
    ORDER BY claim_id DESC
");

$rows = [];
$totalAmount = 0;
while ($row = $result->fetch_assoc()) {
    $rows[] = $row;
    $totalAmount += $row['claim_amount'];
}

// Stats
$stats = [];
$stats['total']    = count($rows);
$stats['approved'] = count(array_filter($rows, fn($r) => $r['status'] === 'approved'));
$stats['rejected'] = count(array_filter($rows, fn($r) => $r['status'] === 'rejected'));
$stats['pending']  = count(array_filter($rows, fn($r) => $r['status'] === 'pending'));

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Claims Report - <?= date('d M Y') ?></title>
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { font-family: Arial, sans-serif; font-size: 12px; color: #1e293b; background: #fff; }
  .header { background: linear-gradient(135deg, #2563eb, #1d4ed8); color: white; padding: 24px 32px; }
  .header h1 { font-size: 22px; font-weight: 700; }
  .header p { font-size: 12px; opacity: 0.85; margin-top: 4px; }
  .meta { padding: 16px 32px; background: #f8fafc; border-bottom: 1px solid #e2e8f0; display: flex; gap: 32px; }
  .meta span { font-size: 11px; color: #64748b; }
  .meta strong { color: #0f172a; }
  .stats { display: flex; gap: 16px; padding: 20px 32px; }
  .stat-card { flex: 1; padding: 12px 16px; border-radius: 8px; text-align: center; }
  .stat-card.total    { background: #eff6ff; border: 1px solid #bfdbfe; }
  .stat-card.approved { background: #f0fdf4; border: 1px solid #bbf7d0; }
  .stat-card.rejected { background: #fef2f2; border: 1px solid #fecaca; }
  .stat-card.pending  { background: #fffbeb; border: 1px solid #fde68a; }
  .stat-card .num { font-size: 24px; font-weight: 700; }
  .stat-card.total .num    { color: #2563eb; }
  .stat-card.approved .num { color: #10b981; }
  .stat-card.rejected .num { color: #ef4444; }
  .stat-card.pending .num  { color: #f59e0b; }
  .stat-card .label { font-size: 10px; color: #64748b; margin-top: 2px; }
  .table-wrap { padding: 0 32px 32px; }
  table { width: 100%; border-collapse: collapse; margin-top: 8px; }
  thead tr { background: #2563eb; color: white; }
  thead th { padding: 10px 8px; text-align: left; font-size: 11px; font-weight: 600; }
  tbody tr:nth-child(even) { background: #f8fafc; }
  tbody tr:hover { background: #eff6ff; }
  tbody td { padding: 8px; font-size: 11px; border-bottom: 1px solid #e2e8f0; }
  .badge { display: inline-block; padding: 2px 8px; border-radius: 12px; font-size: 10px; font-weight: 600; }
  .badge-approved { background: #d1fae5; color: #065f46; }
  .badge-rejected { background: #fee2e2; color: #991b1b; }
  .badge-pending  { background: #fef3c7; color: #92400e; }
  tfoot tr { background: #1e293b; color: white; }
  tfoot td { padding: 10px 8px; font-weight: 600; font-size: 11px; }
  .footer { text-align: center; padding: 16px; color: #94a3b8; font-size: 10px; border-top: 1px solid #e2e8f0; }
  @media print {
    body { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
    .no-print { display: none; }
  }
</style>
</head>
<body>

<div class="no-print" style="padding:16px 32px;background:#fef3c7;border-bottom:2px solid #f59e0b;">
  <strong>Preview Mode:</strong> Press <kbd>Ctrl+P</kbd> (or <kbd>Cmd+P</kbd>) to save as PDF or print.
  &nbsp;|&nbsp; <a href="javascript:window.print()" style="color:#2563eb;font-weight:bold;">🖨️ Print / Save PDF</a>
  &nbsp;|&nbsp; <a href="javascript:window.close()">✕ Close</a>
</div>

<div class="header">
  <h1>🏥 Health Care Claim Analytics Report</h1>
  <p>Generated on <?= date('d F Y, h:i A') ?> &nbsp;|&nbsp; Powered by ClaimAnalytics Portal</p>
</div>

<div class="meta">
  <span>Report Period: <strong><?= $date_from ?: 'All Time' ?> <?= ($date_from && $date_to) ? 'to ' . $date_to : '' ?></strong></span>
  <?php if ($status): ?><span>Status Filter: <strong><?= ucfirst($status) ?></strong></span><?php endif; ?>
  <?php if ($claim_type): ?><span>Claim Type: <strong><?= $claim_type ?></strong></span><?php endif; ?>
  <?php if ($search): ?><span>Search: <strong>"<?= htmlspecialchars($search) ?>"</strong></span><?php endif; ?>
  <span>Total Amount: <strong>₹<?= number_format($totalAmount, 2) ?></strong></span>
</div>

<div class="stats">
  <div class="stat-card total"><div class="num"><?= $stats['total'] ?></div><div class="label">TOTAL CLAIMS</div></div>
  <div class="stat-card approved"><div class="num"><?= $stats['approved'] ?></div><div class="label">APPROVED</div></div>
  <div class="stat-card rejected"><div class="num"><?= $stats['rejected'] ?></div><div class="label">REJECTED</div></div>
  <div class="stat-card pending"><div class="num"><?= $stats['pending'] ?></div><div class="label">PENDING</div></div>
</div>

<div class="table-wrap">
  <table>
    <thead>
      <tr>
        <th>#</th>
        <th>Claim ID</th>
        <th>Patient Name</th>
        <th>Age</th>
        <th>Gender</th>
        <th>Claim Type</th>
        <th>Amount (₹)</th>
        <th>Status</th>
        <th>Submitted Date</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($rows as $i => $row): ?>
      <tr>
        <td><?= $i + 1 ?></td>
        <td><strong>#<?= htmlspecialchars($row['claim_id']) ?></strong></td>
        <td><?= htmlspecialchars($row['patient_name']) ?></td>
        <td><?= htmlspecialchars($row['patient_age']) ?></td>
        <td><?= htmlspecialchars($row['patient_gender']) ?></td>
        <td><?= htmlspecialchars($row['claim_type']) ?></td>
        <td>₹<?= number_format($row['claim_amount'], 2) ?></td>
        <td><span class="badge badge-<?= $row['status'] ?>"><?= ucfirst($row['status']) ?></span></td>
        <td><?= date('d M Y', strtotime($row['submitted_date'])) ?></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
    <tfoot>
      <tr>
        <td colspan="6"><strong>TOTAL (<?= $stats['total'] ?> claims)</strong></td>
        <td><strong>₹<?= number_format($totalAmount, 2) ?></strong></td>
        <td colspan="2"></td>
      </tr>
    </tfoot>
  </table>
</div>

<div class="footer">
  Health Care Claim Analytics Portal &copy; <?= date('Y') ?> &nbsp;|&nbsp; Confidential Report &nbsp;|&nbsp; Generated <?= date('d M Y H:i:s') ?>
</div>

</body>
</html>

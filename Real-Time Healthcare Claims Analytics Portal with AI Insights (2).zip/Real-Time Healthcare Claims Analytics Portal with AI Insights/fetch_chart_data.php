<?php
/**
 * Fetch Chart Data - AJAX Endpoint
 * Returns JSON data for all dashboard charts and KPIs
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

require_once 'db.php';

$action = $_GET['action'] ?? 'all';

$response = [];

try {
    switch ($action) {

        case 'kpi':
            // KPI Cards
            $response['total']    = $conn->query("SELECT COUNT(*) c FROM claims")->fetch_assoc()['c'];
            $response['approved'] = $conn->query("SELECT COUNT(*) c FROM claims WHERE status='approved'")->fetch_assoc()['c'];
            $response['rejected'] = $conn->query("SELECT COUNT(*) c FROM claims WHERE status='rejected'")->fetch_assoc()['c'];
            $response['pending']  = $conn->query("SELECT COUNT(*) c FROM claims WHERE status='pending'")->fetch_assoc()['c'];
            $response['total_amount'] = $conn->query("SELECT COALESCE(SUM(claim_amount),0) s FROM claims")->fetch_assoc()['s'];
            break;

        case 'claim_type':
            // Bar chart - claims by type
            $result = $conn->query("SELECT claim_type, COUNT(*) total FROM claims GROUP BY claim_type ORDER BY total DESC");
            $labels = []; $data = [];
            while ($row = $result->fetch_assoc()) {
                $labels[] = $row['claim_type'];
                $data[]   = (int)$row['total'];
            }
            $response = ['labels' => $labels, 'data' => $data];
            break;

        case 'status_distribution':
            // Pie chart - status breakdown
            $result = $conn->query("SELECT status, COUNT(*) total FROM claims GROUP BY status");
            $labels = []; $data = [];
            while ($row = $result->fetch_assoc()) {
                $labels[] = ucfirst($row['status']);
                $data[]   = (int)$row['total'];
            }
            $response = ['labels' => $labels, 'data' => $data];
            break;

        case 'monthly_trend':
            // Line chart - monthly claim count
            $result = $conn->query("
                SELECT MONTH(submitted_date) month,
                       MONTHNAME(submitted_date) month_name,
                       COUNT(*) total
                FROM claims
                GROUP BY MONTH(submitted_date), MONTHNAME(submitted_date)
                ORDER BY MONTH(submitted_date)
            ");
            $labels = []; $data = [];
            while ($row = $result->fetch_assoc()) {
                $labels[] = $row['month_name'];
                $data[]   = (int)$row['total'];
            }
            $response = ['labels' => $labels, 'data' => $data];
            break;

        case 'monthly_amount':
            // Line chart - monthly claim amounts
            $result = $conn->query("
                SELECT MONTH(submitted_date) month,
                       MONTHNAME(submitted_date) month_name,
                       SUM(claim_amount) total_amount
                FROM claims
                GROUP BY MONTH(submitted_date), MONTHNAME(submitted_date)
                ORDER BY MONTH(submitted_date)
            ");
            $labels = []; $data = [];
            while ($row = $result->fetch_assoc()) {
                $labels[] = $row['month_name'];
                $data[]   = round((float)$row['total_amount'], 2);
            }
            $response = ['labels' => $labels, 'data' => $data];
            break;

        case 'ai_insights':
            // Generate AI Insights
            $insights = [];

            // Most frequent claim type
            $r = $conn->query("SELECT claim_type, COUNT(*) c FROM claims GROUP BY claim_type ORDER BY c DESC LIMIT 1")->fetch_assoc();
            $insights[] = [
                'icon' => 'bx-trending-up',
                'color' => 'blue',
                'text' => "The most frequent claim type is <strong>{$r['claim_type']}</strong> with {$r['c']} claims — consider allocating dedicated processing resources."
            ];

            // Highest claim
            $r = $conn->query("SELECT patient_name, claim_type, claim_amount FROM claims ORDER BY claim_amount DESC LIMIT 1")->fetch_assoc();
            $amt = '₹' . number_format($r['claim_amount'], 2);
            $insights[] = [
                'icon' => 'bx-dollar-circle',
                'color' => 'purple',
                'text' => "Highest single claim: <strong>{$amt}</strong> for {$r['claim_type']} by {$r['patient_name']}. High-value claims should undergo enhanced review."
            ];

            // Average claim amount
            $r = $conn->query("SELECT AVG(claim_amount) avg FROM claims")->fetch_assoc();
            $avg = '₹' . number_format($r['avg'], 2);
            $insights[] = [
                'icon' => 'bx-bar-chart-alt-2',
                'color' => 'teal',
                'text' => "Average claim amount is <strong>{$avg}</strong>. Claims significantly above this threshold require manual verification."
            ];

            // Approval rate
            $total    = $conn->query("SELECT COUNT(*) c FROM claims")->fetch_assoc()['c'];
            $approved = $conn->query("SELECT COUNT(*) c FROM claims WHERE status='approved'")->fetch_assoc()['c'];
            $rejected = $conn->query("SELECT COUNT(*) c FROM claims WHERE status='rejected'")->fetch_assoc()['c'];
            $pending  = $conn->query("SELECT COUNT(*) c FROM claims WHERE status='pending'")->fetch_assoc()['c'];

            $approvalRate  = $total > 0 ? round(($approved / $total) * 100, 1) : 0;
            $rejectionRate = $total > 0 ? round(($rejected / $total) * 100, 1) : 0;
            $pendingRate   = $total > 0 ? round(($pending  / $total) * 100, 1) : 0;

            $approvalColor = $approvalRate >= 75 ? 'green' : ($approvalRate >= 50 ? 'yellow' : 'red');
            $insights[] = [
                'icon' => 'bx-check-circle',
                'color' => $approvalColor,
                'text' => "Approval rate is <strong>{$approvalRate}%</strong>. " . ($approvalRate >= 75 ? "Efficient claim processing is maintaining high approval throughput." : "Review bottlenecks to improve approval pipeline.")
            ];

            $rejColor = $rejectionRate > 20 ? 'red' : 'orange';
            $insights[] = [
                'icon' => 'bx-x-circle',
                'color' => $rejColor,
                'text' => "Rejection rate is <strong>{$rejectionRate}%</strong>. " . ($rejectionRate > 20 ? "High rejection rate detected — audit rejection reasons for systemic issues." : "Rejection rate is within acceptable range.")
            ];

            if ($pendingRate > 15) {
                $insights[] = [
                    'icon' => 'bx-time-five',
                    'color' => 'orange',
                    'text' => "<strong>{$pendingRate}%</strong> of claims are pending ({$pending} claims). Immediate administrative attention is required to clear the backlog."
                ];
            }

            // Month with highest claims
            $r = $conn->query("
                SELECT MONTHNAME(submitted_date) month_name, COUNT(*) c
                FROM claims
                GROUP BY MONTH(submitted_date), MONTHNAME(submitted_date)
                ORDER BY c DESC LIMIT 1
            ")->fetch_assoc();
            $insights[] = [
                'icon' => 'bx-calendar-star',
                'color' => 'indigo',
                'text' => "<strong>{$r['month_name']}</strong> recorded the highest claim volume with {$r['c']} submissions. Staffing levels should be reviewed for this period."
            ];

            // Gender distribution
            $r = $conn->query("SELECT patient_gender, COUNT(*) c FROM claims GROUP BY patient_gender ORDER BY c DESC LIMIT 1")->fetch_assoc();
            $insights[] = [
                'icon' => 'bx-user-circle',
                'color' => 'pink',
                'text' => "<strong>{$r['patient_gender']}</strong> patients represent the largest claimant group ({$r['c']} claims). Tailor health programs to address this demographic's primary needs."
            ];

            $response = ['insights' => $insights];
            break;

        case 'search':
            // Search & Filter with AJAX
            $search     = $conn->real_escape_string($_GET['search'] ?? '');
            $status     = $conn->real_escape_string($_GET['status'] ?? '');
            $claim_type = $conn->real_escape_string($_GET['claim_type'] ?? '');
            $date_from  = $conn->real_escape_string($_GET['date_from'] ?? '');
            $date_to    = $conn->real_escape_string($_GET['date_to'] ?? '');
            $page       = max(1, (int)($_GET['page'] ?? 1));
            $limit      = 10;
            $offset     = ($page - 1) * $limit;
            $sort_col   = in_array($_GET['sort'] ?? '', ['claim_id','patient_name','claim_type','claim_amount','status','submitted_date']) ? $_GET['sort'] : 'claim_id';
            $sort_dir   = strtoupper($_GET['dir'] ?? 'DESC') === 'ASC' ? 'ASC' : 'DESC';

            $where = [];
            if ($search)     $where[] = "(claim_id LIKE '%{$search}%' OR patient_name LIKE '%{$search}%')";
            if ($status)     $where[] = "status = '{$status}'";
            if ($claim_type) $where[] = "claim_type = '{$claim_type}'";
            if ($date_from)  $where[] = "submitted_date >= '{$date_from}'";
            if ($date_to)    $where[] = "submitted_date <= '{$date_to}'";

            $whereStr = $where ? 'WHERE ' . implode(' AND ', $where) : '';

            $total_result = $conn->query("SELECT COUNT(*) c FROM claims {$whereStr}")->fetch_assoc()['c'];

            $result = $conn->query("
                SELECT claim_id, patient_name, patient_age, patient_gender, claim_type, claim_amount, status, submitted_date
                FROM claims {$whereStr}
                ORDER BY {$sort_col} {$sort_dir}
                LIMIT {$limit} OFFSET {$offset}
            ");

            $rows = [];
            while ($row = $result->fetch_assoc()) {
                $rows[] = $row;
            }

            // Get unique claim types for filter dropdown
            $types_result = $conn->query("SELECT DISTINCT claim_type FROM claims ORDER BY claim_type");
            $types = [];
            while ($t = $types_result->fetch_assoc()) $types[] = $t['claim_type'];

            $response = [
                'data'        => $rows,
                'total'       => (int)$total_result,
                'page'        => $page,
                'limit'       => $limit,
                'total_pages' => ceil($total_result / $limit),
                'types'       => $types
            ];
            break;

        default:
            // Return all data at once
            $response['kpi'] = [];
            $response['kpi']['total']        = $conn->query("SELECT COUNT(*) c FROM claims")->fetch_assoc()['c'];
            $response['kpi']['approved']     = $conn->query("SELECT COUNT(*) c FROM claims WHERE status='approved'")->fetch_assoc()['c'];
            $response['kpi']['rejected']     = $conn->query("SELECT COUNT(*) c FROM claims WHERE status='rejected'")->fetch_assoc()['c'];
            $response['kpi']['pending']      = $conn->query("SELECT COUNT(*) c FROM claims WHERE status='pending'")->fetch_assoc()['c'];
            $response['kpi']['total_amount'] = $conn->query("SELECT COALESCE(SUM(claim_amount),0) s FROM claims")->fetch_assoc()['s'];
            $response['success'] = true;
            break;
    }

} catch (Exception $e) {
    $response = ['error' => $e->getMessage()];
}

$conn->close();
echo json_encode($response);

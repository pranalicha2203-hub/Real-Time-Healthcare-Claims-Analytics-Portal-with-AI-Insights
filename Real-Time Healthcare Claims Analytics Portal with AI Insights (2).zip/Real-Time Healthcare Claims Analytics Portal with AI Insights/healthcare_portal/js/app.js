/**
 * Health Care Claim Analytics Portal
 * app.js — Main Application Logic
 */

'use strict';

// ============================================================
// GLOBAL STATE
// ============================================================
const App = {
  charts: {},
  currentPage: 1,
  sortCol: 'claim_id',
  sortDir: 'DESC',
  filters: {},
  debounceTimer: null,
};

// ============================================================
// DOM READY
// ============================================================
document.addEventListener('DOMContentLoaded', () => {
  initSidebar();
  initDarkMode();
  initNavbar();
  loadKPIs();
  initCharts();
  loadAIInsights();
  loadClaimsTable();
  initFilters();
  updateDateTime();
  setInterval(updateDateTime, 60000);
});

// ============================================================
// SIDEBAR
// ============================================================
function initSidebar() {
  const toggle = document.getElementById('sidebar-toggle');
  const sidebar = document.getElementById('sidebar');
  const overlay = document.getElementById('sidebar-overlay');

  toggle?.addEventListener('click', () => {
    sidebar.classList.toggle('open');
    overlay.classList.toggle('show');
  });

  overlay?.addEventListener('click', () => {
    sidebar.classList.remove('open');
    overlay.classList.remove('show');
  });

  // Active link highlight
  document.querySelectorAll('.sidebar-menu a').forEach(link => {
    link.addEventListener('click', function () {
      document.querySelectorAll('.sidebar-menu a').forEach(l => l.classList.remove('active'));
      this.classList.add('active');
      // Close sidebar on mobile
      if (window.innerWidth < 768) {
        sidebar.classList.remove('open');
        overlay.classList.remove('show');
      }
    });
  });
}

// ============================================================
// DARK MODE
// ============================================================
function initDarkMode() {
  const toggle = document.getElementById('dark-toggle');
  const isDark = localStorage.getItem('darkMode') === 'true';

  if (isDark) applyDark(true);

  toggle?.addEventListener('click', () => {
    const dark = document.body.classList.toggle('dark-mode');
    localStorage.setItem('darkMode', dark);
    applyDark(dark);
    // Update charts for theme
    setTimeout(updateChartsTheme, 100);
  });
}

function applyDark(dark) {
  const icon = document.querySelector('#dark-toggle i');
  if (!icon) return;
  icon.className = dark ? 'bx bx-sun' : 'bx bx-moon';
}

function updateChartsTheme() {
  const isDark = document.body.classList.contains('dark-mode');
  const gridColor = isDark ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.05)';
  const textColor = isDark ? '#8b949e' : '#64748b';

  Object.values(App.charts).forEach(chart => {
    if (!chart) return;
    if (chart.options.scales) {
      ['x', 'y'].forEach(axis => {
        if (chart.options.scales[axis]) {
          chart.options.scales[axis].grid.color = gridColor;
          chart.options.scales[axis].ticks.color = textColor;
        }
      });
    }
    chart.update('none');
  });
}

// ============================================================
// NAVBAR
// ============================================================
function initNavbar() {
  document.getElementById('refresh-btn')?.addEventListener('click', () => {
    showToast('Refreshing data…', 'info', 'bx-refresh');
    loadKPIs();
    loadAIInsights();
    loadClaimsTable();
  });
}

function updateDateTime() {
  const el = document.getElementById('current-datetime');
  if (!el) return;
  const now = new Date();
  el.textContent = now.toLocaleDateString('en-IN', {
    day: '2-digit', month: 'short', year: 'numeric'
  }) + '  ' + now.toLocaleTimeString('en-IN', {
    hour: '2-digit', minute: '2-digit'
  });
}

// ============================================================
// KPI CARDS
// ============================================================
async function loadKPIs() {
  try {
    const data = await apiFetch('fetch_chart_data.php?action=kpi');
    animateCounter('kpi-total',    data.total);
    animateCounter('kpi-approved', data.approved);
    animateCounter('kpi-rejected', data.rejected);
    animateCounter('kpi-pending',  data.pending);
    animateCounter('kpi-amount',   data.total_amount, true);

    // Update percentages
    const t = parseInt(data.total) || 1;
    document.getElementById('kpi-approved-pct').innerHTML = `<i class="bx bx-trending-up"></i> ${Math.round((data.approved / t) * 100)}% approval`;
    document.getElementById('kpi-rejected-pct').innerHTML = `<i class="bx bx-trending-down"></i> ${Math.round((data.rejected / t) * 100)}% rejection`;
    document.getElementById('kpi-pending-pct').innerHTML = `<i class="bx bx-loader-circle"></i> ${Math.round((data.pending / t) * 100)}% pending`;

  } catch (e) {
    console.error('KPI load failed:', e);
  }
}

function animateCounter(id, target, isCurrency = false) {
  const el = document.getElementById(id);
  if (!el) return;
  const start = 0;
  const end = parseFloat(target) || 0;
  const duration = 1200;
  const startTime = performance.now();

  function update(currentTime) {
    const elapsed = currentTime - startTime;
    const progress = Math.min(elapsed / duration, 1);
    const eased = 1 - Math.pow(1 - progress, 3); // ease-out cubic
    const value = start + (end - start) * eased;

    if (isCurrency) {
      el.textContent = '₹' + formatNumber(value);
    } else {
      el.textContent = Math.floor(value).toLocaleString();
    }

    if (progress < 1) requestAnimationFrame(update);
  }

  requestAnimationFrame(update);
}

function formatNumber(n) {
  if (n >= 10000000) return (n / 10000000).toFixed(1) + 'Cr';
  if (n >= 100000)   return (n / 100000).toFixed(1) + 'L';
  if (n >= 1000)     return (n / 1000).toFixed(1) + 'K';
  return Math.floor(n).toLocaleString();
}

// ============================================================
// CHARTS
// ============================================================
const COLORS = {
  blue:   '#2563eb',
  green:  '#10b981',
  red:    '#ef4444',
  amber:  '#f59e0b',
  purple: '#8b5cf6',
  cyan:   '#06b6d4',
  pink:   '#ec4899',
  indigo: '#6366f1',
  teal:   '#14b8a6',
  orange: '#f97316',
};

const PALETTE = Object.values(COLORS);

function chartDefaults() {
  const isDark = document.body.classList.contains('dark-mode');
  return {
    gridColor: isDark ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.05)',
    textColor: isDark ? '#8b949e' : '#64748b',
    fontFamily: "'Inter', sans-serif",
  };
}

async function initCharts() {
  await Promise.all([
    drawClaimTypeChart(),
    drawStatusPieChart(),
    drawMonthlyTrendChart(),
    drawMonthlyAmountChart(),
  ]);
}

async function drawClaimTypeChart() {
  const ctx = document.getElementById('claimTypeChart');
  if (!ctx) return;
  const data = await apiFetch('fetch_chart_data.php?action=claim_type');
  const { gridColor, textColor, fontFamily } = chartDefaults();

  if (App.charts.claimType) App.charts.claimType.destroy();

  App.charts.claimType = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: data.labels,
      datasets: [{
        label: 'Claims',
        data: data.data,
        backgroundColor: PALETTE.slice(0, data.labels.length).map(c => c + 'cc'),
        borderColor:     PALETTE.slice(0, data.labels.length),
        borderWidth: 2,
        borderRadius: 6,
        borderSkipped: false,
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: '#1e293b',
          titleColor: '#f1f5f9',
          bodyColor: '#94a3b8',
          padding: 12,
          cornerRadius: 8,
          callbacks: {
            label: ctx => ` ${ctx.parsed.y} claims`
          }
        }
      },
      scales: {
        x: {
          grid: { color: gridColor },
          ticks: { color: textColor, font: { family: fontFamily, size: 12 } }
        },
        y: {
          grid: { color: gridColor },
          ticks: { color: textColor, font: { family: fontFamily, size: 12 }, stepSize: 1 },
          beginAtZero: true
        }
      }
    }
  });
}

async function drawStatusPieChart() {
  const ctx = document.getElementById('statusPieChart');
  if (!ctx) return;
  const data = await apiFetch('fetch_chart_data.php?action=status_distribution');

  if (App.charts.statusPie) App.charts.statusPie.destroy();

  const colors = {
    'Approved': COLORS.green,
    'Rejected': COLORS.red,
    'Pending':  COLORS.amber,
  };

  const bgColors = data.labels.map(l => colors[l] || COLORS.blue);

  App.charts.statusPie = new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: data.labels,
      datasets: [{
        data: data.data,
        backgroundColor: bgColors.map(c => c + 'cc'),
        borderColor: bgColors,
        borderWidth: 2,
        hoverOffset: 8,
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      cutout: '68%',
      plugins: {
        legend: {
          position: 'bottom',
          labels: {
            color: document.body.classList.contains('dark-mode') ? '#8b949e' : '#64748b',
            font: { family: "'Inter', sans-serif", size: 12 },
            padding: 16,
            usePointStyle: true,
            pointStyleWidth: 10,
          }
        },
        tooltip: {
          backgroundColor: '#1e293b',
          titleColor: '#f1f5f9',
          bodyColor: '#94a3b8',
          padding: 12,
          cornerRadius: 8,
          callbacks: {
            label: ctx => {
              const total = ctx.dataset.data.reduce((a, b) => a + b, 0);
              const pct = Math.round((ctx.parsed / total) * 100);
              return ` ${ctx.label}: ${ctx.parsed} (${pct}%)`;
            }
          }
        }
      }
    }
  });
}

async function drawMonthlyTrendChart() {
  const ctx = document.getElementById('monthlyTrendChart');
  if (!ctx) return;
  const data = await apiFetch('fetch_chart_data.php?action=monthly_trend');
  const { gridColor, textColor, fontFamily } = chartDefaults();

  if (App.charts.monthlyTrend) App.charts.monthlyTrend.destroy();

  App.charts.monthlyTrend = new Chart(ctx, {
    type: 'line',
    data: {
      labels: data.labels,
      datasets: [{
        label: 'Claims',
        data: data.data,
        borderColor: COLORS.blue,
        backgroundColor: createGradient(ctx, COLORS.blue + '40', COLORS.blue + '00'),
        borderWidth: 2.5,
        tension: 0.4,
        fill: true,
        pointBackgroundColor: COLORS.blue,
        pointBorderColor: '#fff',
        pointBorderWidth: 2,
        pointRadius: 4,
        pointHoverRadius: 6,
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: '#1e293b',
          titleColor: '#f1f5f9',
          bodyColor: '#94a3b8',
          padding: 12,
          cornerRadius: 8,
          callbacks: { label: ctx => ` ${ctx.parsed.y} claims` }
        }
      },
      scales: {
        x: {
          grid: { color: gridColor },
          ticks: { color: textColor, font: { family: fontFamily, size: 11 }, maxRotation: 30 }
        },
        y: {
          grid: { color: gridColor },
          ticks: { color: textColor, font: { family: fontFamily, size: 11 }, stepSize: 1 },
          beginAtZero: true
        }
      }
    }
  });
}

async function drawMonthlyAmountChart() {
  const ctx = document.getElementById('monthlyAmountChart');
  if (!ctx) return;
  const data = await apiFetch('fetch_chart_data.php?action=monthly_amount');
  const { gridColor, textColor, fontFamily } = chartDefaults();

  if (App.charts.monthlyAmount) App.charts.monthlyAmount.destroy();

  App.charts.monthlyAmount = new Chart(ctx, {
    type: 'line',
    data: {
      labels: data.labels,
      datasets: [{
        label: 'Amount (₹)',
        data: data.data,
        borderColor: COLORS.purple,
        backgroundColor: createGradient(ctx, COLORS.purple + '40', COLORS.purple + '00'),
        borderWidth: 2.5,
        tension: 0.4,
        fill: true,
        pointBackgroundColor: COLORS.purple,
        pointBorderColor: '#fff',
        pointBorderWidth: 2,
        pointRadius: 4,
        pointHoverRadius: 6,
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: '#1e293b',
          titleColor: '#f1f5f9',
          bodyColor: '#94a3b8',
          padding: 12,
          cornerRadius: 8,
          callbacks: {
            label: ctx => ` ₹${Number(ctx.parsed.y).toLocaleString('en-IN')}`
          }
        }
      },
      scales: {
        x: {
          grid: { color: gridColor },
          ticks: { color: textColor, font: { family: fontFamily, size: 11 }, maxRotation: 30 }
        },
        y: {
          grid: { color: gridColor },
          ticks: {
            color: textColor,
            font: { family: fontFamily, size: 11 },
            callback: v => '₹' + (v >= 100000 ? (v/100000).toFixed(1) + 'L' : v.toLocaleString())
          },
          beginAtZero: true
        }
      }
    }
  });
}

function createGradient(ctx, startColor, endColor) {
  const canvas = ctx.canvas || ctx;
  const gradient = canvas.getContext('2d').createLinearGradient(0, 0, 0, canvas.height || 280);
  gradient.addColorStop(0, startColor);
  gradient.addColorStop(1, endColor);
  return gradient;
}

// ============================================================
// AI INSIGHTS
// ============================================================
async function loadAIInsights() {
  const container = document.getElementById('ai-insights-container');
  if (!container) return;

  container.innerHTML = `
    <div class="ai-loading">
      <div class="spinner"></div>
      <span>Generating AI insights from your data…</span>
    </div>
  `;

  try {
    const data = await apiFetch('fetch_chart_data.php?action=ai_insights');

    if (!data.insights?.length) {
      container.innerHTML = '<div class="ai-loading">No insights available.</div>';
      return;
    }

    container.innerHTML = `<div class="ai-insights-grid">${
      data.insights.map(ins => `
        <div class="insight-item">
          <div class="insight-icon ${ins.color}">
            <i class="bx ${ins.icon}"></i>
          </div>
          <div class="insight-text"><strong>AI Insight:</strong> ${ins.text}</div>
        </div>
      `).join('')
    }</div>`;

  } catch (e) {
    container.innerHTML = '<div class="ai-loading">Failed to load insights.</div>';
  }
}

// ============================================================
// CLAIMS TABLE
// ============================================================
async function loadClaimsTable(page = 1) {
  App.currentPage = page;

  const params = new URLSearchParams({
    action:     'search',
    page:       page,
    sort:       App.sortCol,
    dir:        App.sortDir,
    search:     App.filters.search || '',
    status:     App.filters.status || '',
    claim_type: App.filters.claim_type || '',
    date_from:  App.filters.date_from || '',
    date_to:    App.filters.date_to || '',
  });

  const tbody = document.getElementById('claims-tbody');
  const paginationBar = document.getElementById('pagination-bar');
  const paginationInfo = document.getElementById('pagination-info');

  if (tbody) tbody.innerHTML = `
    <tr><td colspan="8">
      <div class="table-loading">
        <div class="spinner" style="width:20px;height:20px;border-width:2px;"></div>
        Loading claims…
      </div>
    </td></tr>
  `;

  try {
    const data = await apiFetch(`fetch_chart_data.php?${params}`);

    // Populate claim type filter if not yet done
    const typeSelect = document.getElementById('filter-type');
    if (typeSelect && typeSelect.options.length <= 1 && data.types) {
      data.types.forEach(t => {
        const opt = document.createElement('option');
        opt.value = t; opt.textContent = t;
        typeSelect.appendChild(opt);
      });
    }

    if (!data.data?.length) {
      if (tbody) tbody.innerHTML = `
        <tr><td colspan="8">
          <div class="table-empty">
            <i class="bx bx-file-find"></i>
            <h4>No claims found</h4>
            <p>Try adjusting your search or filter criteria</p>
          </div>
        </td></tr>
      `;
      if (paginationInfo) paginationInfo.textContent = '0 results';
      if (paginationBar) document.getElementById('pagination-controls').innerHTML = '';
      return;
    }

    // Render rows
    if (tbody) {
      tbody.innerHTML = data.data.map(row => `
        <tr>
          <td><span class="claim-id">#${escape(row.claim_id)}</span></td>
          <td><span class="patient-name">${escape(row.patient_name)}</span>
            <div style="font-size:11px;color:var(--text-muted)">${escape(row.patient_gender)}, ${escape(row.patient_age)}y</div>
          </td>
          <td>
            <span style="background:var(--primary-light);color:var(--primary);padding:3px 9px;border-radius:12px;font-size:12px;font-weight:600;">
              ${escape(row.claim_type)}
            </span>
          </td>
          <td class="amount-cell">₹${Number(row.claim_amount).toLocaleString('en-IN', {minimumFractionDigits: 2})}</td>
          <td><span class="status-badge badge-${row.status}">${cap(row.status)}</span></td>
          <td>${formatDate(row.submitted_date)}</td>
          <td>
            <div style="display:flex;gap:4px;">
              <button class="btn btn-outline btn-sm" onclick="viewClaim(${row.claim_id})" title="View">
                <i class="bx bx-show"></i>
              </button>
            </div>
          </td>
        </tr>
      `).join('');
    }

    // Pagination info
    const from = (data.page - 1) * data.limit + 1;
    const to   = Math.min(data.page * data.limit, data.total);
    if (paginationInfo) {
      paginationInfo.textContent = `Showing ${from}–${to} of ${data.total} claims`;
    }

    // Pagination controls
    renderPagination(data.page, data.total_pages);

  } catch (e) {
    if (tbody) tbody.innerHTML = `
      <tr><td colspan="8">
        <div class="table-empty">
          <i class="bx bx-error-circle"></i>
          <h4>Error loading data</h4>
          <p>${e.message}</p>
        </div>
      </td></tr>
    `;
  }
}

function renderPagination(current, total) {
  const controls = document.getElementById('pagination-controls');
  if (!controls) return;

  let html = `
    <button class="page-btn" onclick="loadClaimsTable(1)" ${current === 1 ? 'disabled' : ''}>
      <i class="bx bx-chevrons-left"></i>
    </button>
    <button class="page-btn" onclick="loadClaimsTable(${current - 1})" ${current === 1 ? 'disabled' : ''}>
      <i class="bx bx-chevron-left"></i>
    </button>
  `;

  // Page numbers
  const range = pageRange(current, total);
  range.forEach(p => {
    if (p === '…') {
      html += `<span class="page-btn" style="cursor:default">…</span>`;
    } else {
      html += `<button class="page-btn ${p === current ? 'active' : ''}" onclick="loadClaimsTable(${p})">${p}</button>`;
    }
  });

  html += `
    <button class="page-btn" onclick="loadClaimsTable(${current + 1})" ${current === total ? 'disabled' : ''}>
      <i class="bx bx-chevron-right"></i>
    </button>
    <button class="page-btn" onclick="loadClaimsTable(${total})" ${current === total ? 'disabled' : ''}>
      <i class="bx bx-chevrons-right"></i>
    </button>
  `;

  controls.innerHTML = html;
}

function pageRange(current, total) {
  if (total <= 7) return Array.from({length: total}, (_, i) => i + 1);
  const pages = [];
  if (current <= 4) {
    pages.push(1, 2, 3, 4, 5, '…', total);
  } else if (current >= total - 3) {
    pages.push(1, '…', total-4, total-3, total-2, total-1, total);
  } else {
    pages.push(1, '…', current-1, current, current+1, '…', total);
  }
  return pages;
}

// ============================================================
// FILTERS
// ============================================================
function initFilters() {
  const inputs = ['filter-search', 'filter-status', 'filter-type', 'filter-date-from', 'filter-date-to'];

  inputs.forEach(id => {
    const el = document.getElementById(id);
    if (!el) return;
    el.addEventListener('input', debounceFilter);
    el.addEventListener('change', debounceFilter);
  });

  document.getElementById('filter-reset')?.addEventListener('click', resetFilters);
}

function debounceFilter() {
  clearTimeout(App.debounceTimer);
  App.debounceTimer = setTimeout(applyFilters, 400);
}

function applyFilters() {
  App.filters = {
    search:     document.getElementById('filter-search')?.value || '',
    status:     document.getElementById('filter-status')?.value || '',
    claim_type: document.getElementById('filter-type')?.value || '',
    date_from:  document.getElementById('filter-date-from')?.value || '',
    date_to:    document.getElementById('filter-date-to')?.value || '',
  };
  loadClaimsTable(1);
}

function resetFilters() {
  ['filter-search', 'filter-status', 'filter-type', 'filter-date-from', 'filter-date-to'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.value = '';
  });
  App.filters = {};
  loadClaimsTable(1);
  showToast('Filters cleared', 'info', 'bx-filter-alt');
}

// ============================================================
// SORTING
// ============================================================
function sortTable(col) {
  if (App.sortCol === col) {
    App.sortDir = App.sortDir === 'ASC' ? 'DESC' : 'ASC';
  } else {
    App.sortCol = col;
    App.sortDir = 'DESC';
  }

  // Update header icons
  document.querySelectorAll('.sort-icon').forEach(ic => ic.className = 'bx bx-sort sort-icon');
  const icon = document.querySelector(`[data-sort="${col}"] .sort-icon`);
  if (icon) icon.className = `bx bx-sort-${App.sortDir === 'ASC' ? 'up' : 'down'} sort-icon`;

  loadClaimsTable(App.currentPage);
}

// ============================================================
// EXPORT
// ============================================================
function exportExcel() {
  const params = new URLSearchParams(App.filters);
  window.open(`export_excel.php?${params}`, '_blank');
  showToast('Excel export started', 'success', 'bx-spreadsheet');
}

function exportPDF() {
  const params = new URLSearchParams(App.filters);
  window.open(`export_pdf.php?${params}`, '_blank');
  showToast('PDF report opened', 'success', 'bx-file-pdf');
}

function printReport() {
  const params = new URLSearchParams(App.filters);
  const w = window.open(`export_pdf.php?${params}`, '_blank');
  setTimeout(() => w?.print(), 1500);
}

// ============================================================
// VIEW CLAIM (modal/alert placeholder)
// ============================================================
function viewClaim(id) {
  showToast(`Viewing claim #${id}`, 'info', 'bx-show');
}

// ============================================================
// UTILITY FUNCTIONS
// ============================================================
async function apiFetch(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const data = await res.json();
  if (data.error) throw new Error(data.error);
  return data;
}

function escape(str) {
  return String(str ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function cap(str) {
  return str ? str.charAt(0).toUpperCase() + str.slice(1) : '';
}

function formatDate(dateStr) {
  if (!dateStr) return '—';
  const d = new Date(dateStr);
  return d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
}

function showToast(message, type = 'info', icon = 'bx-info-circle') {
  const container = document.getElementById('toast-container');
  if (!container) return;

  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.innerHTML = `<i class="bx ${icon}"></i> ${message}`;
  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(8px)';
    toast.style.transition = 'all .3s';
    setTimeout(() => toast.remove(), 300);
  }, 3000);
}

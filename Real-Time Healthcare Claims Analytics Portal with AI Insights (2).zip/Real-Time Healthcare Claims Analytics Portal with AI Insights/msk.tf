# Subtask 2.3: Managed Apache Kafka cluster (AWS MSK) for real-time claims streams.
# Spark runs as a containerized job on ECS (see ecs.tf backend service) reading from this cluster.

resource "aws_msk_cluster" "claims" {
  cluster_name           = "${var.project_name}-msk"
  kafka_version          = "3.6.0"
  number_of_broker_nodes = length(aws_subnet.private)

  broker_node_group_info {
    instance_type   = var.kafka_instance_type
    client_subnets  = aws_subnet.private[*].id
    security_groups = [aws_security_group.msk.id]

    storage_info {
      ebs_storage_info {
        volume_size = 100
      }
    }
  }

  encryption_info {
    encryption_in_transit {
      client_broker = "TLS"
      in_cluster    = true
    }
  }

  logging_info {
    broker_logs {
      cloudwatch_logs {
        enabled   = true
        log_group = aws_cloudwatch_log_group.msk.name
      }
    }
  }

  tags = { Name = "${var.project_name}-msk" }
}

resource "aws_cloudwatch_log_group" "msk" {
  name              = "/msk/${var.project_name}"
  retention_in_days = 30
}

output "kafka_bootstrap_brokers_tls" {
  value = aws_msk_cluster.claims.bootstrap_brokers_tls
}

#!/bin/bash
set -e

echo "Starting Spark Structured Streaming job (Kafka -> AI insights)..."
spark-submit \
  --master "${SPARK_MASTER_URL}" \
  --packages org.apache.spark:spark-sql-kafka-0-10_2.12:3.5.0 \
  /app/streaming_job.py &

echo "Starting insights REST API on port 8000..."
exec uvicorn app.api:app --host 0.0.0.0 --port 8000

from kafka import KafkaProducer
import json

producer = KafkaProducer(
    bootstrap_servers=['localhost:9092'],
    value_serializer=lambda v: json.dumps(v).encode('utf-8')
)

claim = {
    "patient": "John",
    "amount": 2500,
    "status": "Pending"
}

# Sending the data
producer.send('claims', claim)

# Add this to ensure the message is sent before the program closes
producer.flush()

print("Claim Sent")
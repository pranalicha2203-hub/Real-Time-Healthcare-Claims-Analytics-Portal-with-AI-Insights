document.addEventListener("DOMContentLoaded", () => {
    // UI Form Section Containers
    const regSection = document.getElementById('registrationSection');
    const loginSection = document.getElementById('loginSection');
    const forgotSection = document.getElementById('forgotSection');

    // UI Interactive Navigation Anchors
    const linkToLogin = document.getElementById('linkToLogin');
    const linkToRegister = document.getElementById('linkToRegister');
    const linkToForgot = document.getElementById('linkToForgot');
    const forgotBackToLogin = document.getElementById('forgotBackToLogin');

    // Forms
    const regForm = document.getElementById('registrationForm');
    const loginForm = document.getElementById('loginForm');
    const forgotForm = document.getElementById('forgotForm');

    // --- SCREEN NAVIGATION ROUTERS ---
    function switchView(targetSection) {
        clearAllErrors();
        [regSection, loginSection, forgotSection].forEach(sec => sec.classList.remove('active-section'));
        targetSection.classList.add('active-section');
    }

    linkToLogin.addEventListener('click', () => switchView(loginSection));
    linkToRegister.addEventListener('click', () => switchView(regSection));
    linkToForgot.addEventListener('click', () => switchView(forgotSection));
    forgotBackToLogin.addEventListener('click', () => switchView(loginSection));

    // --- FORM VALIDATION UTILITIES (Subtasks 1, 2 & 3) ---
    function displayFieldError(inputElement, errorContainerId, text) {
        inputElement.style.borderColor = "var(--danger)";
        const container = document.getElementById(errorContainerId);
        container.innerText = text;
        container.style.display = "block";
    }

    function clearAllErrors() {
        document.querySelectorAll('.error-message').forEach(el => {
            el.innerText = "";
            el.style.display = "none";
        });
        document.querySelectorAll('input').forEach(input => {
            input.style.borderColor = "var(--border)";
        });
    }

    function validateEmail(email) {
        const regex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
        return regex.test(email);
    }

    function validatePassword(pass) {
        // High safety metrics requirement check: 8+ Chars, Numbers, Special characters, Upper+Lower Cases
        return pass.length >= 8 && /[A-Z]/.test(pass) && /[a-z]/.test(pass) && /[0-9]/.test(pass) && /[@$!%*?&]/.test(pass);
    }

    // ==========================================
    // ➤ STORY 1: USER REGISTRATION INTEGRATION 
    // ==========================================
    regForm.addEventListener('submit', function(event) {
        event.preventDefault(); 
        clearAllErrors();

        const usernameEl = document.getElementById('username');
        const emailEl = document.getElementById('email');
        const passwordEl = document.getElementById('password');

        let isValid = true;

        // Subtask 1: Email Format Verification
        if (!validateEmail(emailEl.value)) {
            displayFieldError(emailEl, 'regEmailError', 'Please supply a standard corporate domain format (e.g., name@hospital.com).');
            isValid = false;
        }

        // Subtask 2: Strong Password Verification
        if (!validatePassword(passwordEl.value)) {
            displayFieldError(passwordEl, 'regPasswordError', 'Requires at least 8 characters including an uppercase, lowercase letter, a digit, and a special character.');
            isValid = false;
        }

        if (!isValid) return; // Terminate execution if requirements fail validation

        const registrationData = {
            username: usernameEl.value,
            email: emailEl.value,
            password: passwordEl.value,
            role: document.getElementById('roleSelection').value
        };

        const jsonPayload = JSON.stringify(registrationData);

        // Your Main Server Execution Endpoint Pipeline
        fetch('/api/auth/register', { 
            method: 'POST',
            headers: { 
                'Content-Type': 'application/json' 
            },
            body: jsonPayload
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Registration failed on your main server');
            }
            return response.json();
        })
        .then(data => {
            console.log('Success:', data);
            alert('Registration Successful on Your Server!');
            regForm.reset();
            switchView(loginSection); // Auto navigate to dashboard login view
        })
        .catch(error => {
            console.error('Error:', error);
            // Dynamic form fallback reporting
            displayFieldError(emailEl, 'regEmailError', 'Database system processing exception. Check logs.');
        });

        // Vedant\'s Server (Epic 7 Backend API Node Services integration framework gateway)
        fetch('http://localhost:8080/api/auth/register', { 
            method: 'POST',
            headers: { 
                'Content-Type': 'application/json' 
            },
            body: jsonPayload
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Registration failed on Vedant\'s server');
            }
            return response.json();
        })
        .then(vedantData => {
            console.log('Success on Vedant\'s System node mapping proxy:', vedantData);
        })
        .catch(error => {
            console.error('Error:', error);
        });
    });

    // ==========================================
    // ➤ STORY 2: LOGIN SYSTEM (Tasks 2, 3 & 4)
    // ==========================================
    loginForm.addEventListener('submit', function(event) {
        event.preventDefault();
        clearAllErrors();

        const loginEmailEl = document.getElementById('loginEmail');
        const loginPasswordEl = document.getElementById('loginPassword');

        if (!validateEmail(loginEmailEl.value)) {
            displayFieldError(loginEmailEl, 'loginEmailError', 'Please enter a valid structure email.');
            return;
        }

        const loginPayload = JSON.stringify({
            email: loginEmailEl.value,
            password: loginPasswordEl.value
        });

        // Mirroring execution endpoints architectures to match project criteria 
        fetch('/api/auth/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: loginPayload
        })
        .then(response => {
            if (!response.ok) throw new Error('System credentials authorization mismatch.');
            return response.json();
        })
        .then(data => {
            console.log('Login Success on Core Portal Hub:', data);
            alert('Authentication Granted! Session token established.');
            loginForm.reset();
        })
        .catch(error => {
            console.error('Core Portal Login Exception Context Error:', error);
        });

        // Forwarding to Vedant\'s API service module instance loop
        fetch('http://localhost:8080/api/auth/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: loginPayload
        })
        .then(response => {
            if (!response.ok) throw new Error('Failed validation credential processing checkpoint inside backend engine.');
            return response.json();
        })
        .then(vedantLoginData => {
            console.log('Success authentication route inside Vedant\'s container module layer:', vedantLoginData);
            // Save token context matching Epic 7 requirements parameters here mapping session strings configurations
            if(vedantLoginData.token) {
                localStorage.setItem('auth_session_token', vedantLoginData.token);
            }
        })
        .catch(error => {
            displayFieldError(loginPasswordEl, 'loginPasswordError', 'Invalid credentials or communication loss with authentication server.');
            console.error('Vedant API Server Authentication Request Exception Context Error:', error);
        });
    });

    // ==========================================
    // ➤ STORY 3: FORGOT PASSWORD (Tasks 2 & 3)
    // ==========================================
    forgotForm.addEventListener('submit', function(event) {
        event.preventDefault();
        clearAllErrors();

        const forgotEmailEl = document.getElementById('forgotEmail');
        const newPasswordEl = document.getElementById('newPassword');

        let isForgotFormValid = true;

        if (!validateEmail(forgotEmailEl.value)) {
            displayFieldError(forgotEmailEl, 'forgotEmailError', 'Please provide an authenticated configuration directory email.');
            isForgotFormValid = false;
        }

        if (!validatePassword(newPasswordEl.value)) {
            displayFieldError(newPasswordEl, 'newPasswordError', 'Requires at least 8 characters with upper, lower, numeric, and special characters components.');
            isForgotFormValid = false;
        }

        if (!isForgotFormValid) return;

        const forgotPayload = JSON.stringify({
            email: forgotEmailEl.value,
            newPassword: newPasswordEl.value
        });

        // Processing Recovery Handlers via API instances
        fetch('/api/auth/forgot-password', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: forgotPayload
        })
        .then(response => {
            if (!response.ok) throw new Error('Recovery verification rejection protocol initiated.');
            return response.json();
        })
        .then(data => {
            console.log('Password successfully reset on Main Hub instance:', data);
            alert('Password update successful! Returning to sign in.');
            forgotForm.reset();
            switchView(loginSection);
        })
        .catch(error => {
            console.error('Recovery tracking core network execution failure trace:', error);
        });

        // Connecting recovery channel updates into backend nodes
        fetch('http://localhost:8080/api/auth/forgot-password', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: forgotPayload
        })
        .then(response => {
            if (!response.ok) throw new Error('Backend failed to verify domain profile context state records lookup query parameters.');
            return response.json();
        })
        .then(vedantForgotResult => {
            console.log('Recovery routine successfully acknowledged inside Vedant\'s server process pipeline stack:', vedantForgotResult);
        })
        .catch(error => {
            displayFieldError(forgotEmailEl, 'forgotEmailError', 'Verification lookup missed. Email address matching criteria database entry not located.');
            console.error('Vedant Engine Reset Endpoint Error Trace logs:', error);
        });
    });
});
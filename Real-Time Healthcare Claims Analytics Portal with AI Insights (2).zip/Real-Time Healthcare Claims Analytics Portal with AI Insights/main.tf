# Subtask 2.1: Cloud provider infrastructure setup via Terraform (IaC)

terraform {
  required_version = ">= 1.7.0"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }

  backend "s3" {
    bucket = "claims-platform-tfstate"
    key    = "infra/terraform.tfstate"
    region = "us-east-1"
    # encrypt        = true
    # dynamodb_table = "claims-platform-tf-locks"
  }
}

provider "aws" {
  region = var.aws_region
}

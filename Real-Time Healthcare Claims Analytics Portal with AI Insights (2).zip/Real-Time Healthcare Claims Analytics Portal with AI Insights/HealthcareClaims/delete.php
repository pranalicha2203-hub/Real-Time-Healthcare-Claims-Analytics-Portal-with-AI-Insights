<?php

include("db.php");

$id = $_GET['id'];

$conn->query(
"DELETE FROM claims WHERE id='$id'"
);

header("Location:viewclaims.php");

?>
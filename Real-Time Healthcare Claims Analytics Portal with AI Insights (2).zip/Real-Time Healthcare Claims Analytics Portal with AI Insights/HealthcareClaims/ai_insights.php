<?php

include("db.php");

$total = $conn->query(
"SELECT * FROM claims"
)->num_rows;

$approved = $conn->query(
"SELECT * FROM claims WHERE status='Approved'"
)->num_rows;

$approval_rate = 0;

if($total > 0)
{
$approval_rate =
($approved/$total)*100;
}

$highest =
$conn->query(
"SELECT MAX(claim_amount) as maxamount
FROM claims"
);

$highrow =
$highest->fetch_assoc();

$maxamount =
$highrow['maxamount'];

$treatment =
$conn->query(
"SELECT treatment,
COUNT(*) as total
FROM claims
GROUP BY treatment
ORDER BY total DESC
LIMIT 1"
);

$trow =
$treatment->fetch_assoc();

?>

<!DOCTYPE html>

<html>

<head>

<title>AI Insights</title>

<link rel="stylesheet"
href="style.css">

</head>

<body>

<header>

<h1>AI Insights Dashboard</h1>

</header>

<div class="container">

<div class="card">

<h2><?php echo $total; ?></h2>

<p>Total Claims</p>

</div>

<div class="card">

<h2><?php echo round($approval_rate,2); ?>%</h2>

<p>Approval Rate</p>

</div>

<div class="card">

<h2>₹<?php echo $maxamount; ?></h2>

<p>Highest Claim Amount</p>

</div>

<div class="card">

<h2>
<?php echo $trow['treatment']; ?>
</h2>

<p>Most Common Treatment</p>

</div>

</div>

<div style="
background:white;
padding:20px;
border-radius:10px;
margin-top:20px;
box-shadow:0 0 10px gray;
">

<h2>AI Quick Insights</h2>

<p>
Most claims are currently
<?php

$approved = $conn->query(
"SELECT * FROM claims WHERE status='Approved'"
)->num_rows;

$rejected = $conn->query(
"SELECT * FROM claims WHERE status='Rejected'"
)->num_rows;

if($approved>$rejected)
{
    echo "Approved";
}
else
{
      echo "Rejected";  
}

?>
</p>

<p>
Current approval rate:
<?php
echo round(($approved/$total)*100,2);
?>%
</p>

</div>

<hr>

<div class="container">

<h2>AI Recommendations</h2>

<?php

if($approval_rate < 70)
{
echo "<p>⚠ Low approval rate detected.</p>";
}
else
{
echo "<p>✅ Approval rate is healthy.</p>";
}

if($maxamount > 50000)
{
echo "<p>⚠ High value claim detected. Review required.</p>";
}
else
{
echo "<p>✅ No suspicious high claims.</p>";
}

echo "<h2>AI Risk Score</h2>";

if($approval_rate > 80)
{
echo "<h3>Low Risk</h3>";
}
elseif($approval_rate > 50)
{
echo "<h3>Medium Risk</h3>";
}
else
{
echo "<h3>High Risk</h3>";
}

?>

<h2>Risk Meter</h2>

<?php

if($approval_rate > 80)
{
echo "<h3 style='color:green'>
LOW RISK
</h3>";
}
elseif($approval_rate > 50)
{
echo "<h3 style='color:orange'>
MEDIUM RISK
</h3>";
}
else
{
echo "<h3 style='color:red'>
HIGH RISK
</h3>";
}

?>

</div>

</body>

</html>
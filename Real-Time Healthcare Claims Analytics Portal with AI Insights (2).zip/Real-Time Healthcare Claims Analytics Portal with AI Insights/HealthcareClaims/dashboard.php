<?php

include("db.php");

$total=$conn->query("SELECT * FROM claims")->num_rows;

$approved=$conn->query(
"SELECT * FROM claims WHERE status='Approved'"
)->num_rows;

$rejected=$conn->query(
"SELECT * FROM claims WHERE status='Rejected'"
)->num_rows;

$pending=$conn->query(
"SELECT * FROM claims WHERE status='Pending'"
)->num_rows;

?>

<!DOCTYPE html>
<html>

<head>

<title>Dashboard</title>

<link rel="stylesheet" href="style.css">

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

</head>

<body>

<header>
    <img src="https://cdn-icons-png.flaticon.com/512/2966/2966486.png"
width="80">

<h1>Healthcare Claims Analytics Portal</h1>
<h3>Welcome Administrator</h3>
</header>

<nav>

<a href="dashboard.php">Dashboard</a>

<a href="addclaim.php">Add Claim</a>

<a href="viewclaims.php">View Claims</a>

<a href="about.php">About</a>

<a href="contact.php">Contact</a>

<a href="ai_insights.php">AI Insights</a>

<a href="hospital_analytics.php">
Hospital Analytics
</a>

<a href="treatment_analytics.php">
Treatment Analytics
</a>

<a href="logout.php">
Logout
</a>

</nav>

<div class="card" style="background:#007bff;">
<h2><?php echo $total; ?></h2>
<p>Total Claims</p>
</div>

<div class="card" style="background:#28a745;">
<h2><?php echo $approved; ?></h2>
<p>Approved Claims</p>
</div>

<div class="card" style="background:#dc3545;">
<h2><?php echo $rejected; ?></h2>
<p>Rejected Claims</p>
</div>

<div class="card" style="background:#ffc107;color:black;">
<h2><?php echo $pending; ?></h2>
<p>Pending Claims</p>
</div>

<div class="container">

<h2>System Statistics</h2>

<ul>

<li>Total Records Stored :
<?php echo $total; ?></li>

<li>Approved Claims :
<?php echo $approved; ?></li>

<li>Rejected Claims :
<?php echo $rejected; ?></li>

<li>Pending Claims :
<?php echo $pending; ?></li>

</ul>

</div>

<hr>

<h2>Claims Analytics</h2>

<canvas id="claimsChart"></canvas>

<script>

var approved = <?php echo $approved; ?>;
var rejected = <?php echo $rejected; ?>;
var pending = <?php echo $pending; ?>;

const ctx = document.getElementById('claimsChart');

new Chart(ctx, {
    type: 'pie',
    data: {
        labels: ['Approved','Rejected','Pending'],
        datasets: [{
            data: [approved,rejected,pending]
        }]
    }
});

</script>

</body>
</html>
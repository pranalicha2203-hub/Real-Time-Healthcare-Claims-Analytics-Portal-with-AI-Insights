<!DOCTYPE html>
<html>

<head>

<link rel="stylesheet" href="style.css">

</head>

<body>

<header>

<h1>Contact Us</h1>

</header>

<div class="container">

<p>Email : admin@healthcare.com</p>

<p>Phone : +91 9876543210</p>

<p>Location : Mumbai</p>

</div>

</body>
</html>
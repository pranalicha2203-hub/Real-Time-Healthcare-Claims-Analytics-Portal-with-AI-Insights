<?php

include("db.php");

if(isset($_GET['search']))
{
$search=$_GET['search'];

$result=$conn->query(
"SELECT * FROM claims
WHERE patient_name LIKE '%$search%'"
);
}
else
{
$result=$conn->query(
"SELECT * FROM claims"
);
}

?>

<!DOCTYPE html>
<html>
<head>
<title>View Claims</title>
</head>

<body>

<h2>All Claims</h2>

<table border="1">

<tr>
<th>ID</th>
<th>Patient</th>
<th>Hospital</th>
<th>Treatment</th>
<th>Amount</th>
<th>Date</th>
<th>Status</th>
<th>Delete</th>
<th>Edit</th>
</tr>

<?php

while($row = $result->fetch_assoc())
{
   

?>

<tr>

<td><?php echo $row['id']; ?></td>

<td><?php echo $row['patient_name']; ?></td>

<td><?php echo $row['hospital_name']; ?></td>

<td><?php echo $row['treatment']; ?></td>

<td><?php echo $row['claim_amount']; ?></td>

<td><?php echo $row['claim_date']; ?></td>

<td><?php echo $row['status']; ?></td>

<td>
<a href="delete.php?id=<?php echo $row['id']; ?>">
Delete
</a>
</td>

<td>
<a href="edit.php?id=<?php echo $row['id']; ?>">
Edit
</a>
</td>

</tr>

<?php

}

?>

 <form method="GET">

Search Patient:

<input type="text" name="search">

<input type="submit" value="Search">

</form>

</table>

</body>
</html>
<?php

include("db.php");

$p=$_POST['patient'];
$h=$_POST['hospital'];
$t=$_POST['treatment'];
$a=$_POST['amount'];
$d=$_POST['date'];
$s=$_POST['status'];

$sql="INSERT INTO claims
(patient_name,hospital_name,treatment,
claim_amount,claim_date,status)

VALUES

('$p','$h','$t','$a','$d','$s')";

$conn->query($sql);

echo "Claim Added Successfully";

?>
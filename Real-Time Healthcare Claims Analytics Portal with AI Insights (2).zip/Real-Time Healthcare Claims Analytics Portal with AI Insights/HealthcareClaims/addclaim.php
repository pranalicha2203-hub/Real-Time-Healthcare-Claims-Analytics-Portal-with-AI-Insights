<!DOCTYPE html>
<html>
<head>
<title>Add Claim</title>
</head>
<body>

<h2>Add Healthcare Claim</h2>

<form action="insert.php" method="POST">

Patient Name:
<input type="text" name="patient">

<br><br>

Hospital Name:
<input type="text" name="hospital">

<br><br>

Treatment:
<input type="text" name="treatment">

<br><br>

Amount:
<input type="number" name="amount">

<br><br>

Date:
<input type="date" name="date">

<br><br>

Status:

<select name="status">
<option>Approved</option>
<option>Rejected</option>
<option>Pending</option>
</select>

<br><br>

<input type="submit" value="Save Claim">

</form>

</body>
</html>
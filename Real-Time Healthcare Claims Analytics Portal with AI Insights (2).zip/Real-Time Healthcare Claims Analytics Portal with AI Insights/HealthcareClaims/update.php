<?php

include("db.php");

$id=$_POST['id'];

$p=$_POST['patient'];

$h=$_POST['hospital'];

$t=$_POST['treatment'];

$a=$_POST['amount'];

$s=$_POST['status'];

$conn->query(

"UPDATE claims

SET

patient_name='$p',

hospital_name='$h',

treatment='$t',

claim_amount='$a',

status='$s'

WHERE id='$id'"

);

header(
"Location:viewclaims.php"
);

?>
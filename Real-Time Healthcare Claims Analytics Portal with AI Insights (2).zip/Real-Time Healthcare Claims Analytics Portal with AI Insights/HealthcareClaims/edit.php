<?php

include("db.php");

$id=$_GET['id'];

$result=$conn->query(
"SELECT * FROM claims WHERE id='$id'"
);

$row=$result->fetch_assoc();

?>

<form action="update.php" method="POST">

<input type="hidden"
name="id"
value="<?php echo $row['id']; ?>">

Patient Name:

<input type="text"
name="patient"
value="<?php echo $row['patient_name']; ?>">

<br><br>

Hospital Name:

<input type="text"
name="hospital"
value="<?php echo $row['hospital_name']; ?>">

<br><br>

Treatment:

<input type="text"
name="treatment"
value="<?php echo $row['treatment']; ?>">

<br><br>

Amount:

<input type="number"
name="amount"
value="<?php echo $row['claim_amount']; ?>">

<br><br>

Status:

<select name="status">

<option>
Approved
</option>

<option>
Rejected
</option>

<option>
Pending
</option>

</select>

<br><br>

<input type="submit"
value="Update Claim">

</form>
<?php

$conn = new mysqli(
"localhost",
"root",
"",
"healthcare1",
3307
);

if($conn->connect_error)
{
die("Connection Failed");
}

?>
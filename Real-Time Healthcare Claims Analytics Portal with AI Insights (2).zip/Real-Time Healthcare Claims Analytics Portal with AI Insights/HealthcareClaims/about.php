<!DOCTYPE html>
<html>

<head>

<link rel="stylesheet" href="style.css">

</head>

<body>

<header>

<h1>About Project</h1>

</header>

<div class="container">

<h2>Real-Time Healthcare Claims Analytics Portal with AI Insights</h2>

<p>
This system helps hospitals and insurance companies
manage healthcare claims and generate analytics.
</p>

<p>
Features include:
</p>

<ul>

<li>Claims Management</li>

<li>Dashboard Analytics</li>

<li>AI Insights</li>

<li>Hospital Analysis</li>

</ul>

</div>

</body>
</html>
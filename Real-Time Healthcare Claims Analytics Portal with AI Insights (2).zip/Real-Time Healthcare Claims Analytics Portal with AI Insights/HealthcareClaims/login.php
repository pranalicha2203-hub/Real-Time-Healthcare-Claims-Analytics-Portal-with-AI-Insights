<?php

if(isset($_POST['login']))
{
    $user=$_POST['user'];
    $pass=$_POST['pass'];

    if($user=="admin" && $pass=="123")
    {
        header("Location: dashboard.php");
        exit();
    }
    else
    {
        echo "Invalid Login";
    }
}

?>

<!DOCTYPE html>
<html>
<body>

<h2>Healthcare Claims Login</h2>

<form method="POST">

Username:
<input type="text" name="user">

<br><br>

Password:
<input type="password" name="pass">

<br><br>

<input type="submit" name="login" value="Login">

</form>

</body>
</html>
<?php

include("db.php");

$result=$conn->query(
"SELECT treatment,
COUNT(*) as total
FROM claims
GROUP BY treatment"
);

?>

<!DOCTYPE html>
<html>

<head>

<link rel="stylesheet" href="style.css">

</head>

<body>

<header>

<h1>Treatment Analytics</h1>

</header>

<div class="container">

<table>

<tr>

<th>Treatment</th>
<th>Total Claims</th>

</tr>

<?php

while($row=$result->fetch_assoc())
{

?>

<tr>

<td><?php echo $row['treatment']; ?></td>

<td><?php echo $row['total']; ?></td>

</tr>

<?php

}

?>

</table>

</div>

</body>

</html>
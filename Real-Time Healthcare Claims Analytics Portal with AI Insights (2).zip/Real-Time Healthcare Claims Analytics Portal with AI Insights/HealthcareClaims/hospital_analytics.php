<?php

include("db.php");

$result = $conn->query(
"SELECT hospital_name,
COUNT(*) as totalclaims,
SUM(claim_amount) as totalamount
FROM claims
GROUP BY hospital_name"
);

$chartData = $conn->query(
"SELECT hospital_name, COUNT(*) as totalclaims
FROM claims
GROUP BY hospital_name"
);

$hospitals = [];
$totals = [];

while($row = $chartData->fetch_assoc())
{
    $hospitals[] = $row['hospital_name'];
    $totals[] = $row['totalclaims'];
}

?>

<!DOCTYPE html>
<html>

<head>

<title>Hospital Analytics</title>

<link rel="stylesheet" href="style.css">

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

</head>

<body>

<header>
<h1>Hospital Analytics</h1>
</header>

<div class="container">

<table>

<tr>

<th>Hospital</th>
<th>Total Claims</th>
<th>Total Amount</th>

</tr>

<hr>

<h2>Hospital Claims Chart</h2>

<canvas id="hospitalChart"></canvas>

<?php

while($row=$result->fetch_assoc())
{

?>

<tr>

<td><?php echo $row['hospital_name']; ?></td>

<td><?php echo $row['totalclaims']; ?></td>

<td>₹<?php echo $row['totalamount']; ?></td>

</tr>

<?php
}

?>

<script>

const hctx = document.getElementById('hospitalChart');

new Chart(hctx, {

type: 'bar',

data: {

labels: <?php echo json_encode($hospitals); ?>,

datasets: [{

label:'Claims',

data: <?php echo json_encode($totals); ?>

}]

}

});

</script>

</table>

</div>

</body>

</html>
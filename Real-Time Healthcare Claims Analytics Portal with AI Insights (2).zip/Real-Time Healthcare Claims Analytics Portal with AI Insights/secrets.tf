# Subtask 3.4: Environment variables, API endpoints, and secrets management
# for database connections and AI models.

resource "aws_secretsmanager_secret" "db_connection" {
  name        = "${var.project_name}/db-connection-string"
  description = "Connection string for the claims database (rotated via Secrets Manager)"
}

resource "aws_secretsmanager_secret" "ai_model_keys" {
  name        = "${var.project_name}/ai-model-api-keys"
  description = "API keys / credentials for AI insights models"
}

# Non-sensitive config (API endpoints, feature flags) via SSM Parameter Store
resource "aws_ssm_parameter" "api_base_url" {
  name  = "/${var.project_name}/api_base_url"
  type  = "String"
  value = "https://${var.domain_name}/api"
}

resource "aws_ssm_parameter" "kafka_topic_claims" {
  name  = "/${var.project_name}/kafka_topic_claims"
  type  = "String"
  value = "claims-events"
}

# IAM policy allowing the ECS task role to read these secrets at runtime
resource "aws_iam_role_policy" "task_secrets_access" {
  name = "${var.project_name}-task-secrets-access"
  role = aws_iam_role.ecs_task.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect = "Allow"
      Action = ["secretsmanager:GetSecretValue", "ssm:GetParameter"]
      Resource = [
        aws_secretsmanager_secret.db_connection.arn,
        aws_secretsmanager_secret.ai_model_keys.arn,
        aws_ssm_parameter.api_base_url.arn,
        aws_ssm_parameter.kafka_topic_claims.arn
      ]
    }]
  })
}

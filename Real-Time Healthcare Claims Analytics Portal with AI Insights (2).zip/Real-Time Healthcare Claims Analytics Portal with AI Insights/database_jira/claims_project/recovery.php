<?php
include 'config/db_connect.php';

if (isset($_POST['restore']) && isset($_POST['file'])) {
    $file = $_POST['file'];
    $mysql = "C:\\xampp\\mysql\\bin\\mysql.exe";
    $command = "\"$mysql\" -u root claims_management < \"$file\"";
    system($command);
    echo "<p style='color:green;'>✅ Recovery completed from $file</p>";
}

$backups = glob("backups/*.sql");
?>
<!DOCTYPE html>
<html>
<head><title>Recovery</title></head>
<body>
<h2>Recovery System</h2>
<form method="POST">
    Select Backup: 
    <select name="file" required>
        <?php foreach($backups as $b): ?>
            <option value="<?= $b ?>"><?= basename($b) ?></option>
        <?php endforeach; ?>
    </select>
    <button type="submit" name="restore" onclick="return confirm('Restore database?');">Restore</button>
</form>
</body>
</html>
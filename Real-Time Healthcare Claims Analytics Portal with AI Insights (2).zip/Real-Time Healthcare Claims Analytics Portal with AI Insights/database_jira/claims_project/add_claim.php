<?php
include 'config/db_connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = $_POST['user_id'];
    $type = $_POST['claim_type'];
    $amount = $_POST['claim_amount'];
    $desc = $_POST['claim_description'];

    $stmt = $conn->prepare("INSERT INTO claims (user_id, claim_type, claim_amount, claim_description) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("isds", $user_id, $type, $amount, $desc);
    
    if ($stmt->execute()) {
        $claim_id = $conn->insert_id;
        // Also insert into history
        $conn->query("INSERT INTO claims_history (claim_id, user_id, claim_type, claim_amount, claim_description, status, action_type) 
                      VALUES ($claim_id, $user_id, '$type', $amount, '$desc', 'pending', 'created')");
        echo "<script>alert('Claim stored successfully!'); window.location='view_claims.php';</script>";
    }
}
?>
<!DOCTYPE html>
<html>
<head><title>Add Claim</title><link rel="stylesheet" href="style.css"></head>
<body>
<h2>Submit New Claim</h2>
<form method="POST">
    User ID: <input type="number" name="user_id" required><br><br>
    Claim Type: <input type="text" name="claim_type" required><br><br>
    Amount: <input type="number" step="0.01" name="claim_amount" required><br><br>
    Description: <textarea name="claim_description"></textarea><br><br>
    <button type="submit">Submit Claim</button>
</form>
</body>
</html>
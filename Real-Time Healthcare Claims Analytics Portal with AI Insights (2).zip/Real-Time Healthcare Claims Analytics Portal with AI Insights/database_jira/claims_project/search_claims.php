<?php
include 'config/db_connect.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Patient Search</title>
    <style>
        * { box-sizing: border-box; }
        body { font-family: Arial; margin: 0; padding: 20px; background: #ecf0f1; }
        .container { max-width: 1400px; margin: auto; background: white; padding: 25px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        h2 { color: #2c3e50; border-bottom: 3px solid #3498db; padding-bottom: 10px; }
        
        .search-box { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 25px; border-radius: 10px; margin: 20px 0; color: white; }
        
        .main-search-row { display: flex; gap: 10px; align-items: center; margin-bottom: 15px; flex-wrap: wrap; }
        
        .main-search { flex: 1; min-width: 300px; padding: 15px; font-size: 18px; border: 3px solid white; border-radius: 8px; }
        
        .btn-group { display: flex; gap: 10px; flex-wrap: wrap; }
        
        .btn { padding: 12px 25px; border: none; cursor: pointer; border-radius: 5px; font-size: 15px; font-weight: bold; transition: 0.3s; }
        .btn-exact { background: #e67e22; color: white; }
        .btn-exact:hover { background: #d35400; transform: scale(1.05); }
        .btn-partial { background: #27ae60; color: white; }
        .btn-clear { background: #e74c3c; color: white; }
        
        .stats { background: #d4edda; padding: 15px; border-radius: 8px; margin: 15px 0; color: #155724; font-size: 16px; border-left: 5px solid #28a745; }
        .no-result { background: #f8d7da; color: #721c24; padding: 20px; text-align: center; border-radius: 8px; border-left: 5px solid #dc3545; }
        
        table { width: 100%; border-collapse: collapse; margin-top: 15px; font-size: 13px; }
        th { background: #34495e; color: white; padding: 12px 8px; text-align: left; position: sticky; top: 0; }
        td { padding: 10px 8px; border-bottom: 1px solid #ddd; }
        tr:hover { background: #f8f9fa; }
        tr:nth-child(even) { background: #fafafa; tr.highlight {background: #fff59d !important;} }
        
        .patient-id { background: #3498db; color: white; padding: 4px 8px; border-radius: 4px; font-weight: bold; font-family: monospace; }
        .status-approved { color: #27ae60; font-weight: bold; }
        .status-rejected { color: #e74c3c; font-weight: bold; }
        .status-pending { color: #f39c12; font-weight: bold; }
        
        .pagination { margin: 20px 0; text-align: center; }
        .pagination a { padding: 10px 15px; margin: 2px; background: #3498db; color: white; text-decoration: none; border-radius: 5px; display: inline-block; }
        .pagination a.active { background: #2c3e50; }
        
        .tips { background: #fff3cd; padding: 12px; border-radius: 5px; margin: 10px 0; color: #856404; }
        
        .highlight-box { 
            background: #ffebee; 
            border-left: 4px solid #f44336; 
            padding: 15px; 
            margin: 10px 0;
            border-radius: 5px;
            animation: pulse 2s infinite;
        }
        @keyframes pulse {
            0% { background-color: #ffebee; }
            50% { background-color: #ffcdd2; }
            100% { background-color: #ffebee; }
        }
        
        .advanced-filters { 
            background: rgba(255,255,255,0.2); 
            padding: 15px; 
            border-radius: 8px; 
            margin-top: 15px; 
            display: none;
        }
        .advanced-filters.show { display: block; }
        .toggle-btn { 
            background: transparent; 
            border: 2px solid white; 
            color: white; 
            padding: 8px 16px; 
            cursor: pointer; 
            border-radius: 5px; 
            font-size: 14px;
        }
    </style>
</head>
<body>
<div class="container">
    <a href="index.php" style="color:#3498db; font-weight:bold;">← Back to Home</a>
    <h2>🔍 Patient Search Engine v2.0</h2>
    
    <div class="tips">
        💡 <b>Quick Search:</b> Type <code>123</code> then press <b style='color:#e67e22;'>EXACT MATCH</b> for single record, or <b style='color:#27ae60;'>PARTIAL SEARCH</b> for all related records
    </div>

    <form method="GET" class="search-box">
        <div class="main-search-row">
            <input type="text" name="q" class="main-search" placeholder="🔍 Search: 123, PAT00001, Sunita, Medical..." value="<?= isset($_GET['q']) ? htmlspecialchars($_GET['q']) : '' ?>" autofocus>
            
            <button type="submit" name="mode" value="exact" class="btn btn-exact">🎯 EXACT MATCH</button>
            <button type="submit" name="mode" value="partial" class="btn btn-partial">🔍 PARTIAL SEARCH</button>
            <a href="search_claims.php"><button type="button" class="btn btn-clear">✖ Clear</button></a>
        </div>
        
        <button type="button" class="toggle-btn" onclick="document.querySelector('.advanced-filters').classList.toggle('show'); this.textContent = this.textContent === '+ Advanced Filters' ? '- Hide Filters' : '+ Advanced Filters'">
            + Advanced Filters
        </button>
        
        <div class="advanced-filters">
            <h4 style="margin-top:0;">Optional Filters:</h4>
            <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px;">
                <input type="text" name="patient_id" placeholder="Patient ID" value="<?= isset($_GET['patient_id']) ? htmlspecialchars($_GET['patient_id']) : '' ?>">
                <input type="text" name="patient_name" placeholder="Patient Name" value="<?= isset($_GET['patient_name']) ? htmlspecialchars($_GET['patient_name']) : '' ?>">
                <select name="type">
                    <option value="">-- All Types --</option>
                    <?php foreach(['Medical','Travel','Accident','Property','Life Insurance','Vehicle','Dental','Maternity','Surgery','Emergency'] as $t): ?>
                        <option value="<?=$t?>" <?= (isset($_GET['type']) && $_GET['type']==$t)?'selected':'' ?>><?=$t?></option>
                    <?php endforeach; ?>
                </select>
                <select name="status">
                    <option value="">-- All Status --</option>
                    <option value="pending" <?= (isset($_GET['status']) && $_GET['status']=='pending')?'selected':'' ?>>Pending</option>
                    <option value="approved" <?= (isset($_GET['status']) && $_GET['status']=='approved')?'selected':'' ?>>Approved</option>
                    <option value="rejected" <?= (isset($_GET['status']) && $_GET['status']=='rejected')?'selected':'' ?>>Rejected</option>
                </select>
                
                <select name="gender">
                    <option value="">-- Gender --</option>
                    <option value="Male" <?= (isset($_GET['gender']) && $_GET['gender']=='Male')?'selected':'' ?>>Male</option>
                    <option value="Female" <?= (isset($_GET['gender']) && $_GET['gender']=='Female')?'selected':'' ?>>Female</option>
                </select>
                <input type="number" name="min_amount" placeholder="Min ₹" value="<?= isset($_GET['min_amount']) ? htmlspecialchars($_GET['min_amount']) : '' ?>">
                <input type="number" name="max_amount" placeholder="Max ₹" value="<?= isset($_GET['max_amount']) ? htmlspecialchars($_GET['max_amount']) : '' ?>">
            </div>
        </div>
    </form>

<?php
$where = [];
$mode = isset($_GET['mode']) ? $_GET['mode'] : 'partial';
$search_term = '';

if (isset($_GET['q']) && trim($_GET['q']) !== '') {
    $q = trim($_GET['q']);
    $search_term = htmlspecialchars($q);
    $sql_q = $conn->real_escape_string($q);

    if ($mode === 'exact') {
        // EXACT MATCH MODE - More strict, fewer results
        if (is_numeric($q)) {
            // If number: Check exact claim_id first, then patient_id partial
            $where[] = "(
                claim_id = $sql_q
                OR CAST(patient_id AS UNSIGNED) = $sql_q  
                OR patient_id = CONCAT('PAT', LPAD($sql_q, 5, '0'))
            )";
        } else {
            // If text: Exact match on name/patient_id, or starts with
            $where[] = "(
                patient_id = '$sql_q'
                OR patient_name = '$sql_q'
                OR claim_type = '$sql_q'
                OR status = '$sql_q'
            )";
        }
    } else {
        // PARTIAL MODE (Original behavior - finds everything)
        if (is_numeric($q)) {
            $where[] = "(
                CAST(claim_id AS CHAR) = '$sql_q' 
                OR CAST(user_id AS CHAR) = '$sql_q' 
                OR patient_age = $sql_q
                OR patient_id LIKE '%$sql_q%'
                OR patient_name LIKE '%$sql_q%'
                OR patient_phone LIKE '%$sql_q%'
                OR claim_description LIKE '%$sql_q%'
                OR claim_type LIKE '%$sql_q%'
                OR claim_amount LIKE '$sql_q%'
            )";
        } else {
            $where[] = "(
                patient_id LIKE '%$sql_q%'
                OR patient_name LIKE '%$sql_q%'
                OR patient_phone LIKE '%$sql_q%'
                OR claim_description LIKE '%$sql_q%'
                OR claim_type LIKE '%$sql_q%'
                OR status LIKE '%$sql_q%'
                OR patient_gender LIKE '%$sql_q%'
            )";
        }
    }
}

// Add advanced filters
if (!empty($_GET['patient_id'])) {
    $pid = $conn->real_escape_string(trim($_GET['patient_id']));
    $where[] = "patient_id LIKE '%$pid%'";
}
if (!empty($_GET['patient_name'])) {
    $pname = $conn->real_escape_string(trim($_GET['patient_name']));
    $where[] = "patient_name LIKE '%$pname%'";
}
if (!empty($_GET['type'])) {
    $type = $conn->real_escape_string($_GET['type']);
    $where[] = "claim_type = '$type'";
}
if (!empty($_GET['status'])) {
    $status = $conn->real_escape_string($_GET['status']);
    $where[] = "status = '$status'";
}
if (!empty($_GET['gender'])) {
    $gender = $conn->real_escape_string($_GET['gender']);
    $where[] = "patient_gender = '$gender'";
}
if (!empty($_GET['min_amount'])) {
    $min = (float)$_GET['min_amount'];
    $where[] = "claim_amount >= $min";
}
if (!empty($_GET['max_amount'])) {
    $max = (float)$_GET['max_amount'];
    $where[] = "claim_amount <= $max";
}

$where_clause = !empty($where) ? "WHERE " . implode(' AND ', $where) : '';
$per_page = 50;
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$offset = ($page - 1) * $per_page;

// Count
$count_sql = "SELECT COUNT(*) as total FROM claims $where_clause";
$total = $conn->query($count_sql)->fetch_assoc()['total'];
$total_pages = ceil($total / $per_page);

if (!empty($where)) {
    $sql = "SELECT * FROM claims $where_clause ORDER BY claim_id ASC LIMIT $per_page OFFSET $offset";
    $result = $conn->query($sql);
    
    echo "<div class='stats'>";
    if ($mode === 'exact') {
        echo "✅ <b>EXACT MATCH</b>: Found <b>$total</b> records";
    } else {
        echo "✅ <b>PARTIAL SEARCH</b>: Found <b>$total</b> records";
    }
    if ($total > $per_page) {
        echo " | Page <b>$page</b> of <b>$total_pages</b>";
    }
    echo "</div>";

    if ($total == 1 && $mode === 'exact') {
        echo "<div class='highlight-box'>🎯 <b>Unique record found!</b> Your exact search term: '$search_term'</div>";
    }

    if ($total > 0) {
        echo "<div style='overflow-x:auto;'><table><tr>
                <th>#</th>
                <th>Claim ID</th><th>Patient ID</th><th>Name</th><th>Age</th>
                <th>Phone</th><th>Type</th><th>Amount</th><th>Status</th><th>Date</th>
              </tr>";
        
        $counter = $offset + 1;
        while ($row = $result->fetch_assoc()) {
            $sc = "status-" . $row['status'];
            
            // Highlight if this matches the search query exactly
            $highlight = false;
            if ($search_term && (
                $row['claim_id'] == $search_term || 
                $row['patient_id'] == $search_term ||
                stristr($row['patient_name'], $search_term)
            )) {
                $highlight = true;
            }
            
            $class = $highlight ? ' class="highlight"' : '';
            
            echo "<tr{$class}>
                <td>{$counter}</td>
                <td>#{$row['claim_id']}</td>
                <td><span class='patient-id'>{$row['patient_id']}</span></td>
                <td><b>" . htmlspecialchars($row['patient_name']) . "</b></td>
                <td>{$row['patient_age']}</td>
                <td>{$row['patient_phone']}</td>
                <td>{$row['claim_type']}</td>
                <td>₹" . number_format($row['claim_amount'], 2) . "</td>
                <td class='$sc'>" . ucfirst($row['status']) . "</td>
                <td>" . date('d-M-Y', strtotime($row['submitted_date'])) . "</td>
            </tr>";
            $counter++;
        }
        echo "</table></div>";
        
        if ($total_pages > 1) {
            echo '<div class="pagination">';
            $qs = $_GET; unset($qs['page']);
            if ($page > 1) { $qs['page']=$page-1; echo "<a href='?".http_build_query($qs)."'>« Prev</a>"; }
            for($i=max(1,$page-3); $i<=min($total_pages,$page+3); $i++) {
                $qs['page']=$i; $a=($i==$page)?'active':'';
                echo "<a href='?".http_build_query($qs)."' class='$a'>$i</a>";
            }
            if ($page < $total_pages) { $qs['page']=$page+1; echo "<a href='?".http_build_query($qs)."'>Next »</a>"; }
            echo '</div>';
        }
    } else {
        echo "<div class='no-result'>❌ No results found for '<b>$search_term</b>'</div>";
    }
} else {
    echo "<div class='stats'>💡 Enter search term above. Total database: <b>" . number_format($conn->query("SELECT COUNT(*) FROM claims")->fetch_row()[0]) . "</b> records</div>";
    
    $preview = $conn->query("SELECT * FROM claims ORDER BY RAND() LIMIT 10");
    if ($preview && $preview->num_rows > 0) {
        echo "<h3>📋 Random Sample:</h3><table><tr>
                <th>Claim ID</th><th>Patient ID</th><th>Name</th><th>Type</th><th>Amount</th>
              </tr>";
        while($r=$preview->fetch_assoc()){
            echo "<tr><td>#{$r['claim_id']}</td><td>{$r['patient_id']}</td><td>".htmlspecialchars($r['patient_name'])."</td><td>{$r['claim_type']}</td><td>₹".number_format($r['claim_amount'],2)."</td></tr>";
        }
        echo '</table>';
    }
}
$conn->close();
?>
</div>
</body>
</html>
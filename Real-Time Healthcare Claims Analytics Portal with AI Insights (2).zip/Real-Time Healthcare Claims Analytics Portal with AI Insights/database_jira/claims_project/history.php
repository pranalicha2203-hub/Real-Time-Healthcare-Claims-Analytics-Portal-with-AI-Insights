<?php include 'config/db_connect.php'; ?>
<!DOCTYPE html>
<html>
<head><title>History</title><link rel="stylesheet" href="style.css"></head>
<body>
<h2>Complete Claim History</h2>
<table border="1" cellpadding="8">
<tr><th>ID</th><th>Claim ID</th><th>User</th><th>Type</th><th>Amount</th><th>Status</th><th>Action</th><th>Date</th></tr>
<?php
$sql = "SELECT * FROM claims_history ORDER BY action_date DESC";
$result = $conn->query($sql);
while ($row = $result->fetch_assoc()) {
    echo "<tr>
        <td>{$row['history_id']}</td>
        <td>{$row['claim_id']}</td>
        <td>{$row['user_id']}</td>
        <td>{$row['claim_type']}</td>
        <td>₹{$row['claim_amount']}</td>
        <td>{$row['status']}</td>
        <td>{$row['action_type']}</td>
        <td>{$row['action_date']}</td>
    </tr>";
}
?>
</table>
</body>
</html>
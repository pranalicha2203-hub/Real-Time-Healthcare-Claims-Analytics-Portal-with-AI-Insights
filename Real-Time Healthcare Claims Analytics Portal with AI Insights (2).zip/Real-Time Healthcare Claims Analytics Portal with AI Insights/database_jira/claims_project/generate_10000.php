<?php
include 'config/db_connect.php';
set_time_limit(600);
ini_set('memory_limit', '512M');

echo "<h2>Generating 10,000 Patient Records... Please Wait...</h2>";

// Add 20 users
for ($u = 1; $u <= 20; $u++) {
    $username = "user_" . $u;
    $email = "user$u@test.com";
    $conn->query("INSERT IGNORE INTO users (username, password, role, email) 
                  VALUES ('$username', 'pass123', 'user', '$email')");
}

// Data arrays
$claim_types = ['Medical', 'Travel', 'Accident', 'Property', 'Life Insurance', 'Vehicle', 'Dental', 'Maternity', 'Surgery', 'Emergency'];
$statuses = ['pending', 'approved', 'rejected'];
$descriptions = [
    'Hospital admission charges', 'Emergency surgery cost', 'Doctor consultation fees',
    'Flight cancellation refund', 'Car accident damage', 'Workplace injury',
    'House fire damage', 'Life insurance claim', 'Vehicle engine repair',
    'Maternity expenses', 'Heart surgery claim', 'Dental treatment',
    'Eye surgery', 'Cancer treatment', 'Diabetes care', 'Kidney treatment'
];

$first_names = ['Rahul', 'Priya', 'Amit', 'Sneha', 'Vikram', 'Pooja', 'Rajesh', 'Anjali', 'Suresh', 'Kavita', 'Manoj', 'Neha', 'Arun', 'Divya', 'Ramesh', 'Sunita', 'Ashok', 'Meera', 'Sanjay', 'Asha'];
$last_names = ['Patil', 'Sharma', 'Kumar', 'Singh', 'Verma', 'Joshi', 'Desai', 'Kulkarni', 'Mehta', 'Gupta', 'Yadav', 'Reddy', 'Iyer', 'Nair', 'Khan'];
$genders = ['Male', 'Female'];

$conn->autocommit(FALSE);
$success = 0;

for ($i = 1; $i <= 10000; $i++) {
    // Generate Patient ID like PAT00001, PAT00002...
    $patient_id = "PAT" . str_pad($i, 5, '0', STR_PAD_LEFT);
    
    $user_id = rand(1, 20);
    $patient_name = $first_names[array_rand($first_names)] . ' ' . $last_names[array_rand($last_names)];
    $age = rand(1, 90);
    $gender = $genders[array_rand($genders)];
    $phone = "9" . rand(100000000, 999999999);
    
    $type = $claim_types[array_rand($claim_types)];
    $amount = rand(1000, 200000) + (rand(0, 99) / 100);
    $desc = $descriptions[array_rand($descriptions)];
    $status = $statuses[array_rand($statuses)];
    $days_ago = rand(0, 730);
    
    $desc_safe = $conn->real_escape_string($desc);
    $name_safe = $conn->real_escape_string($patient_name);
    
    $sql = "INSERT INTO claims (user_id, patient_id, patient_name, patient_age, patient_gender, patient_phone, claim_type, claim_amount, claim_description, status, submitted_date) 
            VALUES ($user_id, '$patient_id', '$name_safe', $age, '$gender', '$phone', '$type', $amount, '$desc_safe', '$status', DATE_SUB(NOW(), INTERVAL $days_ago DAY))";
    
    if ($conn->query($sql)) {
        $claim_id = $conn->insert_id;
        $conn->query("INSERT INTO claims_history (claim_id, user_id, patient_id, patient_name, claim_type, claim_amount, claim_description, status, action_type) 
                      VALUES ($claim_id, $user_id, '$patient_id', '$name_safe', '$type', $amount, '$desc_safe', '$status', 'created')");
        $success++;
    }
    
    if ($i % 500 == 0) {
        $conn->commit();
        echo "✅ Inserted $i records...<br>";
        flush();
        ob_flush();
    }
}

$conn->commit();
$conn->autocommit(TRUE);

echo "<h1 style='color:green;'>🎉 Successfully Added $success Patient Records!</h1>";
echo "<a href='search_claims.php'>🔍 Search Now</a> | ";
echo "<a href='index.php'>Back to Home</a>";

$conn->close();
?>
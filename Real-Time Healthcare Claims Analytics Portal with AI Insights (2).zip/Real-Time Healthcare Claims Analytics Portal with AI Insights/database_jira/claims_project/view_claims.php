<?php include 'config/db_connect.php'; ?>
<!DOCTYPE html>
<html>
<head><title>All Claims</title><link rel="stylesheet" href="style.css"></head>
<body>
<h2>All Stored Claims</h2>
<a href="add_claim.php">+ Add New Claim</a> | 
<a href="search_claims.php">Search</a> | 
<a href="history.php">History</a> | 
<a href="backup.php">Backup</a>
<table border="1" cellpadding="8">
<tr><th>ID</th><th>User</th><th>Type</th><th>Amount</th><th>Status</th><th>Date</th></tr>
<?php
// Optimized query using indexes
$sql = "SELECT claim_id, user_id, claim_type, claim_amount, status, submitted_date 
        FROM claims ORDER BY submitted_date DESC LIMIT 100";
$result = $conn->query($sql);
while ($row = $result->fetch_assoc()) {
    echo "<tr>
        <td>{$row['claim_id']}</td>
        <td>{$row['user_id']}</td>
        <td>{$row['claim_type']}</td>
        <td>₹{$row['claim_amount']}</td>
        <td>{$row['status']}</td>
        <td>{$row['submitted_date']}</td>
    </tr>";
}
?>
</table>
</body>
</html>
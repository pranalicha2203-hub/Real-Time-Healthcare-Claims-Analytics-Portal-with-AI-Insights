<?php
include 'config/db_connect.php';
?>
<!DOCTYPE html>
<html>
<head>
    <title>Project Status - Epic 6 Verification</title>
    <style>
        body { font-family: Arial; padding: 30px; background: #f4f6f9; }
        .container { max-width: 1000px; margin: auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        h1 { color: #2c3e50; border-bottom: 3px solid #3498db; padding-bottom: 10px; }
        h2 { color: #34495e; margin-top: 30px; }
        .check { color: #27ae60; font-weight: bold; }
        .cross { color: #e74c3c; font-weight: bold; }
        .warning { color: #f39c12; font-weight: bold; }
        table { width: 100%; border-collapse: collapse; margin: 15px 0; }
        th { background: #3498db; color: white; padding: 12px; text-align: left; }
        td { padding: 10px; border-bottom: 1px solid #ddd; }
        .progress { background: #ecf0f1; border-radius: 10px; overflow: hidden; height: 30px; margin: 10px 0; }
        .progress-bar { background: linear-gradient(90deg, #27ae60, #2ecc71); height: 100%; color: white; text-align: center; line-height: 30px; font-weight: bold; }
        .summary-box { background: #d4edda; padding: 20px; border-radius: 10px; border-left: 5px solid #28a745; margin: 20px 0; }
    </style>
</head>
<body>
<div class="container">
    <h1>📊 Epic 6: Database Management - Status Report</h1>
    <p><b>Owner:</b> Shubham Patil</p>

<?php
// Initialize counters
$total_tasks = 8;
$completed = 0;

echo "<h2>📁 STORY 1: Claims Storage</h2>";
echo "<table>";
echo "<tr><th>Task</th><th>Status</th><th>Details</th></tr>";

// Task 1: Database Schema Design
$tables = ['users', 'claims', 'claims_history', 'backup_logs'];
$schema_ok = true;
foreach ($tables as $t) {
    $r = $conn->query("SHOW TABLES LIKE '$t'");
    if ($r->num_rows == 0) $schema_ok = false;
}
if ($schema_ok) {
    echo "<tr><td>1. Database Schema Design</td><td class='check'>✅ DONE</td><td>4 tables created</td></tr>";
    $completed++;
} else {
    echo "<tr><td>1. Database Schema Design</td><td class='cross'>❌ INCOMPLETE</td><td>Missing tables</td></tr>";
}

// Task 2: Table Creation
$cols = $conn->query("DESCRIBE claims");
$col_count = $cols->num_rows;
if ($col_count >= 10) {
    echo "<tr><td>2. Table Creation</td><td class='check'>✅ DONE</td><td>$col_count columns in claims table</td></tr>";
    $completed++;
} else {
    echo "<tr><td>2. Table Creation</td><td class='warning'>⚠️ PARTIAL</td><td>Only $col_count columns</td></tr>";
}

// Task 3: Data Storage
$count = $conn->query("SELECT COUNT(*) as c FROM claims")->fetch_assoc()['c'];
if ($count > 0) {
    echo "<tr><td>3. Data Storage</td><td class='check'>✅ DONE</td><td>" . number_format($count) . " records stored</td></tr>";
    $completed++;
} else {
    echo "<tr><td>3. Data Storage</td><td class='cross'>❌ INCOMPLETE</td><td>No data stored</td></tr>";
}

// Task 4: Query Optimization
$indexes = $conn->query("SHOW INDEX FROM claims");
$index_count = $indexes->num_rows;
if ($index_count >= 5) {
    echo "<tr><td>4. Query Optimization</td><td class='check'>✅ DONE</td><td>$index_count indexes created</td></tr>";
    $completed++;
} else {
    echo "<tr><td>4. Query Optimization</td><td class='warning'>⚠️ PARTIAL</td><td>Only $index_count indexes - need more</td></tr>";
}
echo "</table>";

echo "<h2>📚 STORY 2: Historical Data Management</h2>";
echo "<table>";
echo "<tr><th>Task</th><th>Status</th><th>Details</th></tr>";

// Task 5: Search Functionality
if (file_exists('search_claims.php')) {
    echo "<tr><td>1. Search Functionality</td><td class='check'>✅ DONE</td><td>Advanced search with EXACT/PARTIAL modes</td></tr>";
    $completed++;
} else {
    echo "<tr><td>1. Search Functionality</td><td class='cross'>❌ MISSING</td><td>File not found</td></tr>";
}

// Task 6: Data Retrieval
if (file_exists('view_claims.php') && file_exists('history.php')) {
    echo "<tr><td>2. Data Retrieval</td><td class='check'>✅ DONE</td><td>view_claims.php + history.php</td></tr>";
    $completed++;
} else {
    echo "<tr><td>2. Data Retrieval</td><td class='cross'>❌ MISSING</td><td>Files not found</td></tr>";
}

// Task 7: Backup Management
if (file_exists('backup.php')) {
    $backup_count = $conn->query("SELECT COUNT(*) as c FROM backup_logs")->fetch_assoc()['c'];
    echo "<tr><td>3. Backup Management</td><td class='check'>✅ DONE</td><td>backup.php exists | $backup_count backups created</td></tr>";
    $completed++;
} else {
    echo "<tr><td>3. Backup Management</td><td class='cross'>❌ MISSING</td><td>backup.php not found</td></tr>";
}

// Task 8: Recovery System
if (file_exists('recovery.php')) {
    echo "<tr><td>4. Recovery System</td><td class='check'>✅ DONE</td><td>recovery.php exists</td></tr>";
    $completed++;
} else {
    echo "<tr><td>4. Recovery System</td><td class='cross'>❌ MISSING</td><td>recovery.php not found</td></tr>";
}
echo "</table>";

// Summary
$percentage = round(($completed / $total_tasks) * 100);
echo "<div class='summary-box'>";
echo "<h2 style='margin-top:0;'>📈 Overall Project Status</h2>";
echo "<div class='progress'><div class='progress-bar' style='width: $percentage%'>$percentage% Complete</div></div>";
echo "<p><b>Completed Tasks:</b> $completed / $total_tasks</p>";

if ($percentage == 100) {
    echo "<h3 style='color:#27ae60;'>🎉 ALL REQUIREMENTS FULFILLED! Project Ready for Submission!</h3>";
} elseif ($percentage >= 75) {
    echo "<h3 style='color:#f39c12;'>⚠️ Almost Done! Complete remaining tasks.</h3>";
} else {
    echo "<h3 style='color:#e74c3c;'>❌ More work needed</h3>";
}
echo "</div>";

// Database Statistics
echo "<h2>📊 Database Statistics</h2>";
echo "<table>";
$claims_count = $conn->query("SELECT COUNT(*) as c FROM claims")->fetch_assoc()['c'];
$history_count = $conn->query("SELECT COUNT(*) as c FROM claims_history")->fetch_assoc()['c'];
$users_count = $conn->query("SELECT COUNT(*) as c FROM users")->fetch_assoc()['c'];
$backup_count = $conn->query("SELECT COUNT(*) as c FROM backup_logs")->fetch_assoc()['c'];

echo "<tr><td>Total Claims</td><td>" . number_format($claims_count) . "</td></tr>";
echo "<tr><td>History Records</td><td>" . number_format($history_count) . "</td></tr>";
echo "<tr><td>Users</td><td>" . number_format($users_count) . "</td></tr>";
echo "<tr><td>Backups</td><td>" . number_format($backup_count) . "</td></tr>";
echo "<tr><td>Total Indexes on claims table</td><td>$index_count</td></tr>";
echo "</table>";

echo "<h2>🔗 Quick Links</h2>";
echo "<ul>";
echo "<li><a href='index.php'>🏠 Home</a></li>";
echo "<li><a href='add_claim.php'>➕ Add Claim</a></li>";
echo "<li><a href='view_claims.php'>📋 View Claims</a></li>";
echo "<li><a href='search_claims.php'>🔍 Search</a></li>";
echo "<li><a href='history.php'>📚 History</a></li>";
echo "<li><a href='backup.php'>💾 Backup</a></li>";
echo "<li><a href='recovery.php'>♻️ Recovery</a></li>";
echo "</ul>";
?>
</div>
</body>
</html>
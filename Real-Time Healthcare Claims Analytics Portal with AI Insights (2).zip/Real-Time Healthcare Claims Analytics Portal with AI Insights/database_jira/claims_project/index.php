<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Claims Management</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>🗄️ Claims Database Management System</h1>
    <ul>
        <li><a href="add_claim.php">➕ Add New Claim</a></li>
        <li><a href="view_claims.php">📋 View All Claims</a></li>
        <li><a href="search_claims.php">🔍 Search Claims</a></li>
        <li><a href="history.php">📚 View History</a></li>
        <li><a href="backup.php">💾 Backup Database</a></li>
        <li><a href="recovery.php">♻️ Recovery System</a></li>
    </ul>
</body>
</html>
<?php
include 'config/db_connect.php';

if (isset($_POST['backup'])) {
    $backupDir = "backups/";
    if (!is_dir($backupDir)) mkdir($backupDir);
    
    $file = $backupDir . "backup_" . date("Y-m-d_H-i-s") . ".sql";
    
    // Path to mysqldump in XAMPP
    $mysqldump = "C:\\xampp\\mysql\\bin\\mysqldump.exe";
    $command = "\"$mysqldump\" -u root claims_management > \"$file\"";
    system($command, $output);
    
    if (file_exists($file)) {
        $conn->query("INSERT INTO backup_logs (backup_file, status, notes) VALUES ('$file', 'success', 'Manual backup')");
        echo "<p style='color:green;'>✅ Backup created: $file</p>";
    } else {
        $conn->query("INSERT INTO backup_logs (backup_file, status, notes) VALUES ('$file', 'failed', 'Backup failed')");
        echo "<p style='color:red;'>❌ Backup failed</p>";
    }
}
?>
<!DOCTYPE html>
<html>
<head><title>Backup</title><link rel="stylesheet" href="style.css"></head>
<body>
<h2>Backup Management</h2>
<form method="POST">
    <button type="submit" name="backup">Create Backup Now</button>
</form>

<h3>Backup History</h3>
<table border="1" cellpadding="8">
<tr><th>ID</th><th>File</th><th>Date</th><th>Status</th></tr>
<?php
$result = $conn->query("SELECT * FROM backup_logs ORDER BY backup_date DESC");
while ($row = $result->fetch_assoc()) {
    echo "<tr>
        <td>{$row['backup_id']}</td>
        <td>{$row['backup_file']}</td>
        <td>{$row['backup_date']}</td>
        <td>{$row['status']}</td>
    </tr>";
}
?>
</table>
</body>
</html>
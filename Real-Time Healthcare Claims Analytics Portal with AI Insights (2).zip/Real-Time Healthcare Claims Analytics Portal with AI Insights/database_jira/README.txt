========================================
CLAIMS MANAGEMENT SYSTEM
Epic 6: Database Management
Owner: Shubham Patil
========================================

INSTALLATION STEPS:
-------------------

STEP 1: INSTALL XAMPP
- Download from: https://www.apachefriends.org/
- Install with default settings (C:\xampp)

STEP 2: START XAMPP
- Open XAMPP Control Panel
- Click "Start" for Apache (should be GREEN)
- Click "Start" for MySQL (should be GREEN)

STEP 3: COPY PROJECT FILES
- Copy the 'claims_project' folder from this package
- Paste it in: C:\xampp\htdocs\
- Final path should be: C:\xampp\htdocs\claims_project\

STEP 4: CREATE DATABASE
- Open browser
- Go to: http://localhost/phpmyadmin
- Click "New" button (left sidebar)
- Type database name: claims_management
- Click "Create" button

STEP 5: IMPORT DATABASE
- Click on 'claims_management' database (left side)
- Click "Import" tab at top
- Click "Choose File" button
- Select: claims_management.sql (from this package)
- Scroll down and click "Go" button
- Wait for success message

STEP 6: RUN PROJECT
- Open browser
- Go to: http://localhost/claims_project/
- DONE! Project is running!

========================================
FEATURES INCLUDED:
- 10,000 Patient Records
- Advanced Search Engine
- Add/View Claims
- History Tracking
- Backup & Recovery System
- 22 Database Indexes (Optimized)
========================================

NEED HELP? Contact: Shubham Patil
========================================
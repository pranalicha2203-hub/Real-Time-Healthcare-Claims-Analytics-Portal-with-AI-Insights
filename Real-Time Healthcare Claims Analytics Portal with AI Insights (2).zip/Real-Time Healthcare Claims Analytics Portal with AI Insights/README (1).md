# Claims Analytics Platform — Deployment Code

Ready-to-use code for all four phases of the deployment plan.

## 1) Docker setup
- `docker/Dockerfile.frontend` — multi-stage React build served by Nginx (1.1)
- `docker/Dockerfile.backend` — Spark Streaming + AI insights API on Bitnami Spark (1.2)
- `docker-compose.yml` — local orchestration: Zookeeper, Kafka, backend, frontend, Prometheus, Grafana (1.3)
- `docker/build-and-push.sh` — builds, tags, and pushes images to AWS ECR (1.4)

Run locally:
```bash
docker compose up --build
```

## 2) Cloud deployment (Terraform, in `terraform/`)
- `main.tf`, `variables.tf` — AWS provider + S3 remote state (2.1)
- `ecs.tf` — ECS Fargate cluster running frontend/backend containers (2.2)
- `msk.tf` — Managed Kafka (AWS MSK) cluster for real-time claims streams (2.3)
- CI/CD: `.github/workflows/deploy.yml` — test, build, push to ECR, deploy to ECS (2.4)

Deploy:
```bash
cd terraform
terraform init
terraform plan -var="frontend_image=<ecr-uri>:<tag>" -var="backend_image=<ecr-uri>:<tag>"
terraform apply
```

## 3) Server configuration (Terraform, in `terraform/`)
- `vpc.tf` — VPC, public/private subnets, security groups isolating claims data (3.1)
- `alb.tf` — Application Load Balancer + path-based routing (3.2) and ACM TLS cert + HTTPS redirect (3.3)
- `secrets.tf` — Secrets Manager for DB/AI model credentials, SSM for non-sensitive config (3.4)

## 4) Performance monitoring
- `monitoring/prometheus.yml` — scrapes CPU/memory, Kafka consumer lag, Spark batch latency (4.1, 4.2)
- `monitoring/grafana/` — provisioned datasource + "Real-Time Pipeline Health" dashboard
- `docker-compose.logging.yml` + `monitoring/logstash.conf` + `monitoring/filebeat.yml` — ELK centralized logging (4.3)

Run logging stack alongside the main stack:
```bash
docker compose -f docker-compose.yml -f docker-compose.logging.yml up
```

## Notes / things to fill in before production use
- Replace `claims.example.com` in `terraform/variables.tf` with your real domain.
- Replace the S3 backend bucket name in `terraform/main.tf` with one you own.
- Add your actual application source (`/app` for the backend, root for the React app) — the Dockerfiles assume standard `package.json` / `streaming_job.py` layouts.
- Given this handles healthcare claims data, confirm HIPAA-aligned controls (encryption at rest for MSK/EBS, BAA with AWS, audit logging retention) before go-live.

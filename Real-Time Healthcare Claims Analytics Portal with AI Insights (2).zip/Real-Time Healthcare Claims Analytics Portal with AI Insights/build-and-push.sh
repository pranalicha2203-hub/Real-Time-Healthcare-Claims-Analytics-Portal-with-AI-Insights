#!/bin/bash
# Subtask 1.4: Build, tag, and push verified Docker images to AWS ECR
set -euo pipefail

AWS_ACCOUNT_ID="${AWS_ACCOUNT_ID:?Set AWS_ACCOUNT_ID env var}"
AWS_REGION="${AWS_REGION:-us-east-1}"
ECR_REGISTRY="${AWS_ACCOUNT_ID}.dkr.ecr.${AWS_REGION}.amazonaws.com"
IMAGE_TAG="${IMAGE_TAG:-$(git rev-parse --short HEAD)}"

echo "Logging in to ECR ($ECR_REGISTRY)..."
aws ecr get-login-password --region "$AWS_REGION" \
  | docker login --username AWS --password-stdin "$ECR_REGISTRY"

build_and_push () {
  local name="$1" dockerfile="$2"
  local repo="${ECR_REGISTRY}/claims-platform-${name}"

  echo "Building ${name}..."
  docker build -f "$dockerfile" -t "${repo}:${IMAGE_TAG}" -t "${repo}:latest" .

  echo "Pushing ${name}..."
  docker push "${repo}:${IMAGE_TAG}"
  docker push "${repo}:latest"
}

build_and_push "frontend" "docker/Dockerfile.frontend"
build_and_push "backend"  "docker/Dockerfile.backend"

echo "Done. Images pushed with tag: ${IMAGE_TAG}"

<?php
/**
 * Export Claims to Excel (CSV)
 * Health Care Claim Analytics Portal
 */

require_once 'db.php';

// Build filter query
$search     = $conn->real_escape_string($_GET['search'] ?? '');
$status     = $conn->real_escape_string($_GET['status'] ?? '');
$claim_type = $conn->real_escape_string($_GET['claim_type'] ?? '');
$date_from  = $conn->real_escape_string($_GET['date_from'] ?? '');
$date_to    = $conn->real_escape_string($_GET['date_to'] ?? '');

$where = [];
if ($search)     $where[] = "(claim_id LIKE '%{$search}%' OR patient_name LIKE '%{$search}%')";
if ($status)     $where[] = "status = '{$status}'";
if ($claim_type) $where[] = "claim_type = '{$claim_type}'";
if ($date_from)  $where[] = "submitted_date >= '{$date_from}'";
if ($date_to)    $where[] = "submitted_date <= '{$date_to}'";
$whereStr = $where ? 'WHERE ' . implode(' AND ', $where) : '';

$result = $conn->query("
    SELECT claim_id, patient_id, patient_name, patient_age, patient_gender,
           claim_type, claim_amount, status, submitted_date, updated_date
    FROM claims {$whereStr}
    ORDER BY claim_id DESC
");

// Set headers for Excel download
header('Content-Type: application/vnd.ms-excel');
header('Content-Disposition: attachment; filename="claims_report_' . date('Y-m-d_H-i-s') . '.xls"');
header('Cache-Control: max-age=0');

echo '<table border="1">';
echo '<tr style="background:#2563eb;color:white;font-weight:bold;">';
echo '<th>Claim ID</th><th>Patient ID</th><th>Patient Name</th><th>Age</th><th>Gender</th>';
echo '<th>Claim Type</th><th>Amount (₹)</th><th>Status</th><th>Submitted Date</th><th>Updated Date</th>';
echo '</tr>';

$totalAmount = 0;
$rowCount = 0;

while ($row = $result->fetch_assoc()) {
    $statusColor = match($row['status']) {
        'approved' => '#d1fae5',
        'rejected' => '#fee2e2',
        'pending'  => '#fef3c7',
        default    => '#ffffff'
    };
    echo '<tr>';
    echo '<td>' . htmlspecialchars($row['claim_id']) . '</td>';
    echo '<td>' . htmlspecialchars($row['patient_id']) . '</td>';
    echo '<td>' . htmlspecialchars($row['patient_name']) . '</td>';
    echo '<td>' . htmlspecialchars($row['patient_age']) . '</td>';
    echo '<td>' . htmlspecialchars($row['patient_gender']) . '</td>';
    echo '<td>' . htmlspecialchars($row['claim_type']) . '</td>';
    echo '<td>' . number_format($row['claim_amount'], 2) . '</td>';
    echo '<td style="background:' . $statusColor . ';font-weight:bold;">' . ucfirst(htmlspecialchars($row['status'])) . '</td>';
    echo '<td>' . htmlspecialchars($row['submitted_date']) . '</td>';
    echo '<td>' . htmlspecialchars($row['updated_date']) . '</td>';
    echo '</tr>';
    $totalAmount += $row['claim_amount'];
    $rowCount++;
}

echo '<tr style="background:#f1f5f9;font-weight:bold;">';
echo '<td colspan="6">TOTAL (' . $rowCount . ' claims)</td>';
echo '<td>₹' . number_format($totalAmount, 2) . '</td>';
echo '<td colspan="3"></td>';
echo '</tr>';

echo '</table>';
$conn->close();

from flask import Flask, render_template, request, jsonify
import sqlite3

app = Flask(__name__)

def init_db():
    conn = sqlite3.connect('claims.db')
    cur = conn.cursor()

    cur.execute('''
    CREATE TABLE IF NOT EXISTS claims(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        patient_name TEXT,
        claim_amount REAL,
        status TEXT
    )
    ''')

    conn.commit()
    conn.close()

@app.route('/')
def home():
    conn = sqlite3.connect('claims.db')
    cur = conn.cursor()

    cur.execute("SELECT * FROM claims")
    claims = cur.fetchall()

    conn.close()

    return render_template("index.html", claims=claims)

@app.route('/add_claim', methods=['POST'])
def add_claim():

    patient = request.form['patient']
    amount = request.form['amount']

    conn = sqlite3.connect('claims.db')
    cur = conn.cursor()

    cur.execute(
        "INSERT INTO claims(patient_name,claim_amount,status) VALUES(?,?,?)",
        (patient, amount, "Pending")
    )

    conn.commit()
    conn.close()

    return jsonify({"message":"Claim Added"})

if __name__ == '__main__':
    init_db()
    app.run(debug=True)
<?php
/**
 * Health Care Claim Analytics Portal
 * dashboard.php — Main Entry Point
 */

require_once 'db.php';

// Server-side initial KPI data (prevents flash of empty on load)
$kpi = [
    'total'    => $conn->query("SELECT COUNT(*) c FROM claims")->fetch_assoc()['c'] ?? 0,
    'approved' => $conn->query("SELECT COUNT(*) c FROM claims WHERE status='approved'")->fetch_assoc()['c'] ?? 0,
    'rejected' => $conn->query("SELECT COUNT(*) c FROM claims WHERE status='rejected'")->fetch_assoc()['c'] ?? 0,
    'pending'  => $conn->query("SELECT COUNT(*) c FROM claims WHERE status='pending'")->fetch_assoc()['c'] ?? 0,
    'amount'   => $conn->query("SELECT COALESCE(SUM(claim_amount),0) s FROM claims")->fetch_assoc()['s'] ?? 0,
];

$t = max($kpi['total'], 1);
$kpi['approved_pct'] = round(($kpi['approved'] / $t) * 100, 1);
$kpi['rejected_pct'] = round(($kpi['rejected'] / $t) * 100, 1);
$kpi['pending_pct']  = round(($kpi['pending']  / $t) * 100, 1);

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>ClaimAnalytics — Health Care Claim Portal</title>

  <!-- Bootstrap 5 -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
  <!-- Boxicons -->
  <link rel="stylesheet" href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css">
  <!-- Google Fonts: Inter -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <!-- Custom CSS -->
  <link rel="stylesheet" href="css/style.css">
</head>
<body>

<!-- Sidebar Overlay (mobile) -->
<div class="sidebar-overlay" id="sidebar-overlay"></div>

<!-- ============================================================
     APP WRAPPER
============================================================ -->
<div class="app-wrapper">

  <!-- ============================================================
       SIDEBAR
  ============================================================ -->
  <aside class="sidebar" id="sidebar">

    <!-- Logo -->
    <div class="sidebar-logo">
      <div class="logo-icon"><i class="bx bx-heart-circle"></i></div>
      <div class="logo-text">
        <h2>ClaimAnalytics</h2>
        <span>Healthcare Portal</span>
      </div>
    </div>

    <!-- Navigation -->
    <nav class="sidebar-menu">
      <div class="menu-section-label">Main</div>
      <ul>
        <li>
          <a href="#dashboard" class="active" onclick="scrollToSection('section-kpi')">
            <i class="bx bx-grid-alt"></i>
            <span>Dashboard</span>
          </a>
        </li>
        <li>
          <a href="#reports" onclick="scrollToSection('section-charts')">
            <i class="bx bx-bar-chart-alt-2"></i>
            <span>Reports & Charts</span>
          </a>
        </li>
        <li>
          <a href="#claims" onclick="scrollToSection('section-claims')">
            <i class="bx bx-file-blank"></i>
            <span>Claims</span>
            <span class="badge-pill"><?= $kpi['total'] ?></span>
          </a>
        </li>
        <li>
          <a href="#ai" onclick="scrollToSection('section-ai')">
            <i class="bx bx-brain"></i>
            <span>AI Insights</span>
          </a>
        </li>
      </ul>

      <div class="menu-section-label" style="margin-top:12px;">Analytics</div>
      <ul>
        <li>
          <a href="#" onclick="showToast('Analytics module coming soon','info','bx-line-chart')">
            <i class="bx bx-trending-up"></i>
            <span>Trends</span>
          </a>
        </li>
        <li>
          <a href="#" onclick="showToast('Analytics module coming soon','info','bx-pie-chart-alt')">
            <i class="bx bx-pie-chart-alt-2"></i>
            <span>Statistics</span>
          </a>
        </li>
        <li>
          <a href="#" onclick="showToast('Analytics module coming soon','info','bx-calendar')">
            <i class="bx bx-calendar"></i>
            <span>Monthly View</span>
          </a>
        </li>
      </ul>

      <div class="menu-section-label" style="margin-top:12px;">System</div>
      <ul>
        <li>
          <a href="#" onclick="showToast('Settings module coming soon','info','bx-cog')">
            <i class="bx bx-cog"></i>
            <span>Settings</span>
          </a>
        </li>
        <li>
          <a href="#" onclick="showToast('Help & documentation','info','bx-help-circle')">
            <i class="bx bx-help-circle"></i>
            <span>Help</span>
          </a>
        </li>
      </ul>
    </nav>

    <!-- User Footer -->
    <div class="sidebar-footer">
      <div class="user-info">
        <div class="avatar">A</div>
        <div class="user-details">
          <h4>Admin User</h4>
          <p>Super Administrator</p>
        </div>
      </div>
    </div>

  </aside><!-- /sidebar -->

  <!-- ============================================================
       MAIN CONTENT
  ============================================================ -->
  <div class="main-content">

    <!-- NAVBAR -->
    <nav class="navbar">
      <div class="navbar-left">
        <button id="sidebar-toggle" class="navbar-btn">
          <i class="bx bx-menu"></i>
        </button>
        <div>
          <h1>Healthcare Claim Analytics</h1>
          <div class="breadcrumb">
            <i class="bx bx-home" style="font-size:13px;"></i>
            <span>Dashboard</span>
            <i class="bx bx-chevron-right" style="font-size:13px;"></i>
            <span style="color:var(--primary)">Overview</span>
          </div>
        </div>
      </div>

      <div class="navbar-right">
        <div class="date-badge">
          <i class="bx bx-calendar"></i>
          <span id="current-datetime"></span>
        </div>
        <button class="navbar-btn" id="refresh-btn" title="Refresh Data">
          <i class="bx bx-refresh"></i>
        </button>
        <button class="navbar-btn" title="Notifications">
          <i class="bx bx-bell"></i>
          <span class="dot"></span>
        </button>
        <button class="dark-toggle" id="dark-toggle" title="Toggle Dark Mode">
          <i class="bx bx-moon"></i>
        </button>
      </div>
    </nav>

    <!-- PAGE CONTENT -->
    <div class="page-content">

      <!-- ========================================================
           SECTION 1: KPI CARDS
      ======================================================== -->
      <div id="section-kpi">
        <div class="section-header">
          <h2><i class="bx bx-grid-alt"></i> Dashboard Overview</h2>
          <div class="last-updated">
            <i class="bx bx-time-five"></i>
            <span>Last updated: <span id="current-datetime-2"></span></span>
          </div>
        </div>

        <div class="kpi-grid">

          <!-- Total Claims -->
          <div class="kpi-card kpi-blue">
            <div class="kpi-icon-wrap"><i class="bx bx-clipboard"></i></div>
            <div class="kpi-info">
              <h4>Total Claims</h4>
              <div class="kpi-value counter" id="kpi-total"><?= $kpi['total'] ?></div>
              <span class="kpi-badge"><i class="bx bx-dots-horizontal-rounded"></i> All time</span>
            </div>
          </div>

          <!-- Approved -->
          <div class="kpi-card kpi-green">
            <div class="kpi-icon-wrap"><i class="bx bx-check-shield"></i></div>
            <div class="kpi-info">
              <h4>Approved Claims</h4>
              <div class="kpi-value counter" id="kpi-approved"><?= $kpi['approved'] ?></div>
              <span class="kpi-badge" id="kpi-approved-pct">
                <i class="bx bx-trending-up"></i>
                <?= $kpi['approved_pct'] ?>% approval
              </span>
            </div>
          </div>

          <!-- Rejected -->
          <div class="kpi-card kpi-red">
            <div class="kpi-icon-wrap"><i class="bx bx-shield-x"></i></div>
            <div class="kpi-info">
              <h4>Rejected Claims</h4>
              <div class="kpi-value counter" id="kpi-rejected"><?= $kpi['rejected'] ?></div>
              <span class="kpi-badge" id="kpi-rejected-pct">
                <i class="bx bx-trending-down"></i>
                <?= $kpi['rejected_pct'] ?>% rejection
              </span>
            </div>
          </div>

          <!-- Pending -->
          <div class="kpi-card kpi-amber">
            <div class="kpi-icon-wrap"><i class="bx bx-time-five"></i></div>
            <div class="kpi-info">
              <h4>Pending Claims</h4>
              <div class="kpi-value counter" id="kpi-pending"><?= $kpi['pending'] ?></div>
              <span class="kpi-badge" id="kpi-pending-pct">
                <i class="bx bx-loader-circle"></i>
                <?= $kpi['pending_pct'] ?>% pending
              </span>
            </div>
          </div>

          <!-- Total Amount -->
          <div class="kpi-card kpi-purple">
            <div class="kpi-icon-wrap"><i class="bx bx-rupee"></i></div>
            <div class="kpi-info">
              <h4>Total Claim Amount</h4>
              <div class="kpi-value" id="kpi-amount" style="font-size:22px;">
                ₹<?= number_format($kpi['amount'] / 100000, 1) ?>L
              </div>
              <span class="kpi-badge"><i class="bx bx-money"></i> Cumulative</span>
            </div>
          </div>

        </div>
      </div><!-- /section-kpi -->

      <!-- ========================================================
           SECTION 2: CHARTS
      ======================================================== -->
      <div id="section-charts">
        <div class="section-header">
          <h2><i class="bx bx-bar-chart-alt-2"></i> Reports & Visualization</h2>
        </div>

        <div class="charts-grid">

          <!-- Bar: Claim Type -->
          <div class="card">
            <div class="card-header">
              <h3><i class="bx bx-bar-chart"></i> Claims by Type</h3>
              <div class="chart-toolbar">
                <button class="btn-icon" title="Refresh" onclick="drawClaimTypeChart()">
                  <i class="bx bx-refresh"></i>
                </button>
              </div>
            </div>
            <div class="card-body">
              <div class="chart-wrap"><canvas id="claimTypeChart"></canvas></div>
            </div>
          </div>

          <!-- Pie: Status Distribution -->
          <div class="card">
            <div class="card-header">
              <h3><i class="bx bx-pie-chart-alt-2"></i> Status Distribution</h3>
              <div class="chart-toolbar">
                <button class="btn-icon" title="Refresh" onclick="drawStatusPieChart()">
                  <i class="bx bx-refresh"></i>
                </button>
              </div>
            </div>
            <div class="card-body">
              <div class="chart-wrap"><canvas id="statusPieChart"></canvas></div>
            </div>
          </div>

          <!-- Line: Monthly Trend -->
          <div class="card">
            <div class="card-header">
              <h3><i class="bx bx-trending-up"></i> Monthly Claim Volume</h3>
              <div class="chart-toolbar">
                <button class="btn-icon" title="Refresh" onclick="drawMonthlyTrendChart()">
                  <i class="bx bx-refresh"></i>
                </button>
              </div>
            </div>
            <div class="card-body">
              <div class="chart-wrap"><canvas id="monthlyTrendChart"></canvas></div>
            </div>
          </div>

          <!-- Line: Monthly Amount -->
          <div class="card">
            <div class="card-header">
              <h3><i class="bx bx-line-chart"></i> Monthly Claim Amount (₹)</h3>
              <div class="chart-toolbar">
                <button class="btn-icon" title="Refresh" onclick="drawMonthlyAmountChart()">
                  <i class="bx bx-refresh"></i>
                </button>
              </div>
            </div>
            <div class="card-body">
              <div class="chart-wrap"><canvas id="monthlyAmountChart"></canvas></div>
            </div>
          </div>

        </div>
      </div><!-- /section-charts -->

      <!-- ========================================================
           SECTION 3: AI INSIGHTS
      ======================================================== -->
      <div id="section-ai">
        <div class="ai-panel">
          <div class="ai-panel-header">
            <div class="ai-icon"><i class="bx bx-brain"></i></div>
            <div class="ai-title">
              <h3>AI-Powered Insights</h3>
              <p>Automated analysis and recommendations from your claims data</p>
            </div>
            <div class="ai-badge">Live AI</div>
          </div>
          <div id="ai-insights-container">
            <div class="ai-loading">
              <div class="spinner"></div>
              <span>Analyzing claims data…</span>
            </div>
          </div>
        </div>
      </div><!-- /section-ai -->

      <!-- ========================================================
           SECTION 4: CLAIMS TABLE
      ======================================================== -->
      <div id="section-claims">
        <div class="section-header">
          <h2><i class="bx bx-list-ul"></i> Recent Claims</h2>
          <div class="export-bar">
            <button class="btn btn-success btn-sm" onclick="exportExcel()">
              <i class="bx bx-spreadsheet"></i> Export Excel
            </button>
            <button class="btn btn-danger btn-sm" onclick="exportPDF()">
              <i class="bx bx-file-pdf"></i> Export PDF
            </button>
            <button class="btn btn-outline btn-sm" onclick="printReport()">
              <i class="bx bx-printer"></i> Print
            </button>
          </div>
        </div>

        <!-- Filters -->
        <div class="filters-card">
          <div class="filters-row">
            <div class="filter-group" style="min-width:200px;">
              <label><i class="bx bx-search"></i> Search</label>
              <input type="text" id="filter-search" placeholder="Claim ID or Patient Name…">
            </div>
            <div class="filter-group">
              <label><i class="bx bx-filter"></i> Status</label>
              <select id="filter-status">
                <option value="">All Statuses</option>
                <option value="approved">Approved</option>
                <option value="rejected">Rejected</option>
                <option value="pending">Pending</option>
              </select>
            </div>
            <div class="filter-group">
              <label><i class="bx bx-category"></i> Claim Type</label>
              <select id="filter-type">
                <option value="">All Types</option>
              </select>
            </div>
            <div class="filter-group">
              <label><i class="bx bx-calendar"></i> Date From</label>
              <input type="date" id="filter-date-from">
            </div>
            <div class="filter-group">
              <label><i class="bx bx-calendar"></i> Date To</label>
              <input type="date" id="filter-date-to">
            </div>
            <div class="filter-group" style="flex:0;">
              <label>&nbsp;</label>
              <button class="btn btn-outline" id="filter-reset" style="white-space:nowrap;">
                <i class="bx bx-reset"></i> Reset
              </button>
            </div>
          </div>
        </div>

        <!-- Table Card -->
        <div class="card">
          <div class="table-container">
            <table class="claims-table">
              <thead>
                <tr>
                  <th data-sort="claim_id" onclick="sortTable('claim_id')">
                    Claim ID <i class="bx bx-sort sort-icon"></i>
                  </th>
                  <th data-sort="patient_name" onclick="sortTable('patient_name')">
                    Patient <i class="bx bx-sort sort-icon"></i>
                  </th>
                  <th data-sort="claim_type" onclick="sortTable('claim_type')">
                    Type <i class="bx bx-sort sort-icon"></i>
                  </th>
                  <th data-sort="claim_amount" onclick="sortTable('claim_amount')">
                    Amount <i class="bx bx-sort sort-icon"></i>
                  </th>
                  <th data-sort="status" onclick="sortTable('status')">
                    Status <i class="bx bx-sort sort-icon"></i>
                  </th>
                  <th data-sort="submitted_date" onclick="sortTable('submitted_date')">
                    Submitted <i class="bx bx-sort sort-icon"></i>
                  </th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody id="claims-tbody">
                <tr>
                  <td colspan="7">
                    <div class="table-loading">
                      <div class="spinner" style="width:20px;height:20px;border-width:2px;"></div>
                      Loading claims…
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          <!-- Pagination -->
          <div class="pagination-bar" id="pagination-bar">
            <div class="pagination-info" id="pagination-info">Loading…</div>
            <div class="pagination-controls" id="pagination-controls"></div>
          </div>
        </div>

      </div><!-- /section-claims -->

    </div><!-- /page-content -->
  </div><!-- /main-content -->
</div><!-- /app-wrapper -->

<!-- Toast Container -->
<div class="toast-container" id="toast-container"></div>

<!-- ============================================================
     SCRIPTS
============================================================ -->
<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<!-- Custom App JS -->
<script src="js/app.js"></script>

<script>
// Sync second datetime display
document.addEventListener('DOMContentLoaded', () => {
  const el2 = document.getElementById('current-datetime-2');
  const el1 = document.getElementById('current-datetime');
  if (el2 && el1) {
    setInterval(() => el2.textContent = el1.textContent, 1000);
    setTimeout(() => el2.textContent = el1.textContent, 500);
  }
});

function scrollToSection(id) {
  const el = document.getElementById(id);
  if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
}
</script>

</body>
</html>
